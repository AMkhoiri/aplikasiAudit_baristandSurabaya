<!DOCTYPE html>
<html>
<head>
	@include('layout.head-css')
	<title>Error</title>
</head>
<body>

<div  class="container"  style=" font-size: 50px; font-family: roboto; opacity: 70%;  text-align: center; margin-top: 260px;  color: #9fa0a1;" > 

	~~ <p   class="fa fa-smile-o "   style=" justify-content:  center; font-size:66px; " >  </p> ~~ 
	<h3 style="  text-align: center; color: #9fa0a1; " >Eitss...., Mau Ngapain ? </h3  > 

	<a  class=" btn btn-sm btn-secondary " href="{{url ('/')}}" style=" width: 60px; font-size: 12px;  " > Kembali</a>
</div>

</body>
</html>