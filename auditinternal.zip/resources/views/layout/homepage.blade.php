<!DOCTYPE html>
<html>
<head>
	 @include('layout.head-css')


	<title>Welcome...</title>

  <style >
  #app {
   
  }


</style>
</head>
<body>
<div id="app"  style="  ">

	 <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-primary">
                <div class="container" style="font-size: 12px ">
                   <a class="navbar-brand logo_h" href="#"><img  class="thumbnail"  style=" max-width: 77px;  "  src=" {{ asset('audit/img/bisby.png')}}" alt=""></a>
                 
                  <div class="collapse navbar-collapse" id="navbarNavAltMarkup" >
                    <div   style="margin: 0px;"  class="navbar-nav">
                     <a class="navbar-brand" style=" color:White; font-size: 18px; ">
                        Balai Riset Dan Standarisasi Industri Surabaya - Audit Internal
                    </a>
                    </div>
                   
              </div>

             </div>
    </nav>
<br><br>

    <div class="panel panel-default "  >
    	<div class="container " > 
                <div class="panel-heading"> <a href="" class=" btn " >Beranda</a>   &emsp; >>&emsp; Login Page</div>
         </div>
    </div>


<!-- <nav class="navbar navbar-expand-lg navbar-light " style=" background-color:#F2F3F9   " >

	<div class="container" >
  <div class="container-fluid">
	    <div class="navbar-header" style=" margin-top: 8px;  margin-bottom: 8px; " >
	     
	    </div>

	    <div class="row" >   
	    	<span class=" col-sm-6 fa fa-home " style="font-size: 18px; color: #676768  ; " > &emsp;Beranda &emsp; >></span>
	    	<span class=" col-sm-6 text-right" > 
	    		<a href="#"><span class=" btn   " style=" width: 103px; "> dfdfd</span></a>
	    		 <a href="#"><span class=" btn btn-primary " style=" width: 103px; " > Login Page</span></a>
      			
	    	 </span>


	     </div>
		  
  </div>
</nav> -->

 
  <br><br><br>
     



 </div>
</body>
</html>