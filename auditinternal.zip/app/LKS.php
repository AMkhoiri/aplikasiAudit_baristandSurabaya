<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LKS extends Model
{
    //
    protected $table = 'lks';
}
