<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class auditee extends Model
{
   protected $table ='auditee'; 
   // public $timestamps = false;
}
