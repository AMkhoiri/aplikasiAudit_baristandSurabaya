<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class arsip_catatan extends Model
{
    protected $table = 'arsip_catatan';
    public $timestamps = false;
}
