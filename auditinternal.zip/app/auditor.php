<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class auditor extends Model
{
    protected $table ='auditor'; 
   // public $timestamps = false;
}
