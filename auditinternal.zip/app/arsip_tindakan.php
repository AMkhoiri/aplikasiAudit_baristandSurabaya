<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class arsip_tindakan extends Model
{
       protected $table = 'arsip_tindakan';
    public $timestamps = false;
}
