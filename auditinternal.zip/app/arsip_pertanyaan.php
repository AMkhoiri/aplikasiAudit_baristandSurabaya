<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class arsip_pertanyaan extends Model
{
        protected $table = 'arsip_pertanyaan';
    public $timestamps = false;
}
