<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class catatan extends Model
{
    protected $table = 'catatan';
}
