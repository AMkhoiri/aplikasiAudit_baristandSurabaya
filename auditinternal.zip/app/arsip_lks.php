<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class arsip_lks extends Model
{
        protected $table = 'arsip_lks';
    public $timestamps = false;
}
