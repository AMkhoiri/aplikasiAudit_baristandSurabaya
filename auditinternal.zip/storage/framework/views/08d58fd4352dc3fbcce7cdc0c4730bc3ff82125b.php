<!DOCTYPE html>
<html>
<head>

	<?php echo $__env->make('layout.head-css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->make('kepala.headerkepalabalai', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<title>Kepala Balai</title>
</head>
<body>

<div class="container"  style="font-size: 14px; "> 

	<h5 style="text-align: center;" >DATA PELAKSANA AUDIT</h5><br>

	<div class="table-responsive">
		<table class="table table-striped table-bordered table-hover "  >
		  	
		     <tr  >
		      <th style="text-align:center"> NO</th>
		      <th style="text-align:center">Lokasi Audit</th>
		      <th style="text-align:center">Auditor</th>
		      <th style="text-align:center">Auditee</th> 
		    </tr>


		    <tr>
		   		<td style="text-align:center"> 1</td>
			    <td style=""> Top Manajemen</td>
		      	<td style=""> <?php $no = 0;?> <?php $__currentLoopData = $auditor1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   <?php $no++ ;?>   <?php echo e($no); ?>.  <?php echo e($a->nama); ?> <br><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </td>
		      	<td style=""> <?php $no = 0;?> <?php $__currentLoopData = $auditee1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   <?php $no++ ;?>   <?php echo e($no); ?>.  <?php echo e($a->nama); ?> <br><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
		    </tr>

		     <tr>
		   		<td style="text-align:center"> 2 </td>
			    <td style=""> Sub Bag Tata Usaha</td>
		      	<td style="">  <?php $no = 0;?> <?php $__currentLoopData = $auditor2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   <?php $no++ ;?>   <?php echo e($no); ?>.  <?php echo e($a->nama); ?> <br><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
		      	<td style=""> <?php $no = 0;?> <?php $__currentLoopData = $auditee2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   <?php $no++ ;?>   <?php echo e($no); ?>.  <?php echo e($a->nama); ?> <br><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
		    </tr>

		     <tr>
		   		<td style="text-align:center"> 3 </td>
			    <td style=""> Seksi Pengembangan jasa Teknis</td>
		      	<td style="">  <?php $no = 0;?> <?php $__currentLoopData = $auditor3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   <?php $no++ ;?>   <?php echo e($no); ?>.  <?php echo e($a->nama); ?> <br><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
		      	<td style=""> <?php $no = 0;?> <?php $__currentLoopData = $auditee3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   <?php $no++ ;?>   <?php echo e($no); ?>.  <?php echo e($a->nama); ?> <br><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
		    </tr>

		     <tr>
		   		<td style="text-align:center"> 4</td>
			    <td style=""> Seksi Standarisasi Dan Sertifikasi / Operasional</td>
		      	<td style="">  <?php $no = 0;?> <?php $__currentLoopData = $auditor4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   <?php $no++ ;?>   <?php echo e($no); ?>.  <?php echo e($a->nama); ?> <br><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
		      	<td style=""> <?php $no = 0;?> <?php $__currentLoopData = $auditee4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   <?php $no++ ;?>   <?php echo e($no); ?>.  <?php echo e($a->nama); ?> <br><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
		    </tr>

		     <tr>
		   		<td style="text-align:center"> 5 </td>
			    <td style=""> Seksi Standarisasi Dan Sertifikasi / Mutu</td>
		      	<td style=""> <?php $no = 0;?> <?php $__currentLoopData = $auditor5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   <?php $no++ ;?>   <?php echo e($no); ?>.  <?php echo e($a->nama); ?> <br><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
		      	<td style="">  <?php $no = 0;?> <?php $__currentLoopData = $auditee5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   <?php $no++ ;?>   <?php echo e($no); ?>.  <?php echo e($a->nama); ?> <br><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
		    </tr>

		</table>
		</div>
</div>


</body>
</html>
<?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
