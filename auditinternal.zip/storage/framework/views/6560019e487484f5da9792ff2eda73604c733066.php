<!DOCTYPE html>
<html>
<head>
	<?php echo $__env->make('layout.head-css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<title>Error</title>
</head>
<body>

<div  class="container"  style=" font-size: 50px; font-family: roboto; opacity: 70%;  text-align: center; margin-top: 260px;  color: #9fa0a1;" > 

	~~ <p   class="fa fa-frown-o "   style=" justify-content:  center; font-size:66px; " >  </p> ~~ 
	<h3 style="  text-align: center; color: #9fa0a1; " >Maaf , Anda Tidak Mempunyai Akses Ke Halaman Ini ! </h3  > 

	<a  class=" btn btn-sm btn-secondary " href="<?php echo e(url ('/')); ?>" style=" width: 58px; font-size: 12px;  " > Kembali</a>
</div>

</body>
</html>