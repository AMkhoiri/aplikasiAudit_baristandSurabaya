<!DOCTYPE html>
<html>
<head>

 <?php echo $__env->make('layout.head-css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <?php echo $__env->make('auditee.headerauditee', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<style>
  textarea { font-size: 13px !important; }
</style>

</head>
<body>

<div class="container-fluid" style=" font-size: 12px;">


    

<div class="breadcrumb" style="margin-bottom: 5px;" >
  <div class="container-fluid">
     <div  style="font-size: 20px; color: #3993d0; font-weight: bold; "> <span class="fa fa-file" > </span> Laporan Ketidaksesuaian </div>
   </div>
  </div> 


<div class="table-responsive">
<table class="table  table-striped table-bordered"  >
    <tr>
      <th style="text-align:center;">No LKS</th>
      <th style="text-align:center;  ">Deskripsi Ketidaksesuaian</th>
      <th style="text-align:center;">Dokumen Acuan</th>
          <th style="text-align:center;">SNI ISO/IEC 17065:2012 Klausul</th>
          <th style="text-align:center;">SNI ISO/IEC 17021-1:2015 Klausul</th>
          <th style="text-align:center;">SNI ISO/IEC 17021-1:2017 Klausul</th>
          <th style="text-align:center;">(Dokumen SMM)</th>
    </tr>

    <tr>  
      <td style="text-align:center; "> <?php echo e($lks -> nolks); ?> </td>
      <td style="text-align:left;width: 300px; "> <?php echo e($lks -> deskripsi); ?> </td>
      <td style="text-align:left;width: 160px; "> <?php echo e($lks -> acuan); ?> </td>
      <td style="text-align:left; "> <?php echo e($lks -> iec_2012); ?> </td>
      <td style="text-align:left; "> <?php echo e($lks -> iec_2015); ?> </td>
      <td style="text-align:left; "> <?php echo e($lks -> iec_2017); ?> </td>
      <td style="text-align:left; width: 150px;"> <?php echo e($lks -> smm); ?> </td>
   </tr>

   <?php  $id_lks= $lks->id ?>


   <?php 
 
  $lokasi=$lks->lokasi; 
   $create=$lks ->updated_at;
  
  ?>


  </table>
</div>

</div><br>


<div class="container-fluid" style=" font-size: 12px;">

    

<div class="breadcrumb" style="margin-bottom: 5px;" >
  <div class="container-fluid">
     <div  style="font-size: 20px; color: #3993d0; font-weight: bold; "> <span class="fa fa-pencil" > </span> Tulis Tindakan Perbaikan </div>
   </div>
  </div> 




<div class="breadcrumb" style="margin-bottom: 5px;" >
  <form role="form"  action="<?php echo e(url ('auditee/daftartindakan')); ?>" method="post"  enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>


<div class="row">
    <div class="col-md-4">
      <div class="form-group">
        <label for="akar"><b>Akar Permasalahan  </b></label>
        <textarea cols="80" rows="7" spellcheck="false" class="form-control" placeholder="Tulis Akar Permasalahan" name="akar" id="akar" required></textarea><br>
       
      </div>
    </div>

    <div class="col-md-4">
      <div class="form-group">
       <label for="dilakukan"><b>Tindakan Yang Akan Dilakukan  </b></label>
        <textarea cols="80" rows="7" spellcheck="false" class="form-control" placeholder="Tulis Tindakan Yang Akan Dilakukan" name="dilakukan" id="dilakukan"  required></textarea>
      </div>
    </div>

    <div class="col-md-4">
      <div class="form-group">
        <label for="pencegahan"><b>Tindakan Pencegahan  </b></label>
        <textarea cols="80" rows="7" spellcheck="false" class="form-control" placeholder="Tulis Tindakan Pencegahan" name="pencegahan" id="pencegahan" required></textarea><br>
      

          <input type="hidden" class="form-control"  value="<?php echo e($id_lks); ?>" name="id_lks">
           <input type="hidden" class="form-control"  value="Telah Ditindak" name="status">
           <input type="hidden" class="form-control" id="lokasi" value="<?php echo e($lokasi); ?>" name="lokasi">
           <input type="hidden" class="form-control" id="tanggallks" value="<?php echo e($create); ?>" name="tanggallks">
           <input type="hidden" class="form-control"  value=" <?php echo e($lks ->nolks); ?>" name="nolks">
           
        
       </div>
      </div>
  </div>
  <div class="row">
    <div class="col-md-6">
      <label for="filebukti"><b>Sertakan File Bukti</b> (Ekstensi File: pdf/docx/doc/jpg/jpeg/png/zip/rar  max size: 2mb) </label>
      <input type="file" id="filebukti" class="form-control-file" name="file" style="  " > 


    </div>

    <div class="col-md-6" style="text-align: right;">
       <a  class="btn btn-sm btn-secondary " href="<?php echo e(url ('/auditee/lks-tindakan')); ?> " style=" width: 120px; margin-right: 10px;" ><span class=" fa fa-arrow-left " >  Batal</span></a>
        <button type="submit" class="btn btn-primary btn-sm " style=" width: 120px; " ><span class=" fa fa-save " > Simpan</span></button>
    </div>
  </div>

           <?php if(count($errors) > 0): ?>
          <br><div class="alert alert-danger  " style=" align-content: left; text-align: left; font-size: 13px;" >
              
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php echo e($error); ?>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
          </div>
        <?php endif; ?>  
     
       
      
  </form>

</div>

</div>
</body>

<script>
    var msg = '<?php echo e(Session::get('alert')); ?>';
    var exist = '<?php echo e(Session::has('alert')); ?>';
    if(exist){
      alert(msg);
    }
  </script>



</html>
<?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>