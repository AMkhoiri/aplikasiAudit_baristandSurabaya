<!DOCTYPE html>
<html>
<head>

	<?php echo $__env->make('layout.head-css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->make('auditee.headerauditee', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <style>
    
  </style>

	<title>Daftar Tindakan</title>
</head>
<body>

  <br><br>

<div class="container" style="font-size: 12px; "> 
  <h5 style="text-align: left; " >Area Audit : <br>

    <?php if(Auth::user()->lokasi==NULL): ?>
    <i style=" color: red; " > Akun Anda Tidak Aktif, Silahkan Hubungi Admin !</i>
    <?php else: ?>
    <?php echo e(Auth::user()->lokasi); ?>

    <?php endif; ?>
  </h5><br>
	
    <h5 style="text-align: center;" >DAFTAR TINDAKAN</h5><br>


    <div class="table-responsive">
      		<table class="table table-striped table-bordered  "  >

          	<tr>
              	<th style="text-align:center; width: 40px; ">No</th>
              
                <th style="text-align:center;"> Tindakan </th>
              	<th style="text-align:center; width: 100px; ">Bukti</th>
                <th style="text-align:center; width: 120px; ">Catatan Auditor</th>
                <th style="text-align:center;  width: 80px; ">Status</th>
                <th style="text-align:center;  width: 80px; ">Aksi</th>
          	</tr>

            <?php $no = 0;?>
          <?php $__currentLoopData = $tindaklks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tdk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $no++ ;?>

          <tr>
              <td style=" text-align: center; width: 50px; " ><?php echo e($no); ?>   </td>
              <td style=" padding-left: 10px; width: 280px;" >  <b>Akar Permasalahan:  </b><br> <?php echo $tdk -> akar; ?> <br><br> <b>Tindakan Yang Dilakukan:</b> <br> <?php echo $tdk ->dilakukan; ?>  <br><br> <b>Tindakan Pencegahan: </b> <br><?php echo $tdk -> pencegahan; ?>  </td>            
              <td style=" text-align: center;  width: 100px;  " >  <p class=" fa fa-file-o" >  </p> &ensp;<?php echo e($tdk -> title); ?> 
  

                <?php if( $tdk->title==NULL ): ?>

                <?php if($tdk->status_tindakan==NULL ): ?>

                       
                            <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger col-sm-9 " style=" align-content: left; text-align: left; font-size: 10px;" >
                                
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($error); ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </div>
                            <?php endif; ?>                     
                  
                       <form  style="text-align: left;" action="<?php echo e(route('uploadbukti',$tdk->id_tindakan)); ?>" method="post" enctype="multipart/form-data">       
                         <?php echo e(csrf_field()); ?>

                   
                              <input type="file" name="file" style=" max-width: 160px; " > 
                              <input type="hidden" name="_method" value="PUT">
                         <br><br>
                             <div style=" text-align: center; " >
                                <button type="submit" class="btn  btn-sm " style=" width: 60px; font-size: 10px;">upload</button> 
                             </div>
                      </form>

                      <?php elseif($tdk->status_tindakan=="dikembalikan"): ?>


                        
                            <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger col-sm-9 " style=" align-content: left; text-align: left; font-size: 10px;" >
                                
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($error); ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </div>
                            <?php endif; ?>                     
                  
                       <form  style="text-align: left;" action="<?php echo e(route('uploadbukti',$tdk->id_tindakan)); ?>" method="post" enctype="multipart/form-data">       
                         <?php echo e(csrf_field()); ?>

                   
                              <input type="file" name="file" style=" max-width: 160px; " > 
                              <input type="hidden" name="_method" value="PUT">
                         <br><br>
                             <div style=" text-align: center; " >
                                <button type="submit" class="btn  btn-sm " style=" width: 60px; font-size: 10px;">upload</button> 
                             </div>
                      </form>

                      <?php endif; ?>


                  
                  <?php elseif( $tdk->title==!NULL): ?>

                  <?php if($tdk->status_tindakan==NULL ): ?>
                   <br><br>

                      <form action=" <?php echo e(route ('deletefile', $tdk->id_tindakan)); ?> " method="post">
                      <?php echo e(csrf_field()); ?>

                          <input type="hidden" name="_method" value="DELETE">
                          <button type="submit" style=" width: 60px; font-size: 10px; " onclick=" return confirm(' Anda Yakin Untuk Menghapus File ini ?') " class=" btn btn-danger btn-sm " >hapus file </button>
                      </form>

                      <?php elseif($tdk->status_tindakan=="dikembalikan"): ?>

                        <br><br>

                      <form action=" <?php echo e(route ('deletefile', $tdk->id_tindakan)); ?> " method="post">
                      <?php echo e(csrf_field()); ?>

                          <input type="hidden" name="_method" value="DELETE">
                          <button type="submit" style=" width: 60px; font-size: 10px; " onclick=" return confirm(' Anda Yakin Untuk Menghapus File ini ?') " class=" btn btn-danger btn-sm " >hapus file </button>
                     
                      </form>
                      <?php endif; ?>

                  <?php endif; ?>

              </td>

              <td  style=" width: 170px; " >
                 <?php if( $tdk->status_tindakan=='dikembalikan'): ?>
                 <b>Catatan Auditor: </b><br>
                 <?php echo e($tdk-> catatan_verifikasi); ?>




                 <?php else: ?>
                 <?php endif; ?>

              </td>
              <td style=" text-align: center; width: 80px; " >

                <?php if( $tdk->status_tindakan=='dikembalikan'): ?>
                     <p class="fa fa-undo"  style=" font-size: 1.2em; width: 1.7em; text-align: center; line-height: 0.8em;  background: #c9ba01; color: #fff; border-radius: 0.8em;" > </p><br>
                      Dikembalikan <br> Oleh Auditor<br>

                <?php elseif( $tdk->status_tindakan=='Terkirim'): ?>
                    <i class=" terkirim fa fa-check"  style="font-size: 1.2em; width: 1.7em; text-align: center; line-height: 0.8em;background: green; color: #fff; border-radius: 0.8em;">   </i><br>
                    <?php echo e($tdk->status_tindakan); ?><br><?php echo e($tdk->updated_at->diffForHumans()); ?>


                 <?php elseif( $tdk->status_tindakan=='Ter-Verifikasi'): ?>
                    <i class=" terkirim fa fa-check" style="font-size: 1.2em; width: 1.7em; text-align: center; line-height: 0.8em;background: blue; color: #fff; border-radius: 0.8em;"  >   </i><br>
                    <?php echo e($tdk->status_tindakan); ?><br><?php echo e($tdk->updated_at->diffForHumans()); ?>

    

                <?php endif; ?>

              </td> 


              <td style=" text-align: center; width: 80px; ">
                
                  <?php if( $tdk->status_tindakan==NULL): ?>

                    <a href="<?php echo e(route('edittindakan',$tdk->id_tindakan)); ?>"><button class="btn btn-primary btn-sm" style="width: 60px; font-size: 11px;"><span class=" fa fa-edit " >  Edit</span></button></a>
                  
                      <br><br>
                  

                 <form class="form-horizontal" action="<?php echo e(route('kirimtindakan',$tdk->id_tindakan)); ?>" method="post">
                <?php echo e(csrf_field()); ?>

             
                    <input type="hidden" class="form-control" id="status" name="status" value="Terkirim">             
                    <button type="submit" class="btn btn-sm btn-success" onclick="return confirm('Setelah Terkirim, Anda tidak akan bisa mengubahnya lagi. yakin untuk mengirim Isi Tindakan Ini ? ')"  style="width: 60px; font-size: 11px;" ><span class=" fa fa-send " >  Kirim</span></button>

                    <input type="hidden" name="_method" value="PUT">
                </form>
              
                <?php elseif( $tdk->status_tindakan=='dikembalikan'): ?>

                     <a href="<?php echo e(route('edittindakan',$tdk->id_tindakan)); ?>"><button class="btn btn-primary btn-sm" style=" width: 60px; font-size: 11px; "><span class=" fa fa-edit " >  Edit</span></button></a>
                  
                      <br><br>
                  
                     <form class="form-horizontal" action="<?php echo e(route('kirimtindakan',$tdk->id_tindakan)); ?>" method="post">
                    <?php echo e(csrf_field()); ?>            
                        <input type="hidden" class="form-control" id="status" name="status" value="Terkirim">
                        <button type="submit" class="btn btn-sm btn-success" onclick="return confirm('Setelah Terkirim, Anda tidak akan bisa mengubahnya lagi. yakin untuk mengirim Isi Tindakan Ini ? ')"  style="width:60px; font-size: 11px;" ><span class=" fa fa-send " >  Kirim</span></button>
                        <input type="hidden" name="_method" value="PUT">
                    </form>



                <?php else: ?>
               
                <?php endif; ?>


              </td>
          </tr>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         
        </table>
        </div>
   </div>
  
</body>

<script>
    var msg = '<?php echo e(Session::get('alert')); ?>';
    var exist = '<?php echo e(Session::has('alert')); ?>';
    if(exist){
      alert(msg);
    }
  </script>

</html>
<?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>