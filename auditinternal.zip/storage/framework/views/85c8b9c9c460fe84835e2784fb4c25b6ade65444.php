<!DOCTYPE html>
<html>
<head>
	<?php echo $__env->make('layout.head-css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<title></title>
</head>
<body>


<br><br>
<div class="container" >
		
	 <div class="form row">
	<div class="col-md-3 border border-dark  justify-content-center " style="  " >
		<img  class="thumbnail"  style=" max-width: 190px; margin-left: 16px; "  src=" <?php echo e(asset('audit/img/kemenperin.png')); ?>" alt="">
		
	</div>
		<div class="col-md-9 border  border-dark">			
			<h5 style=" text-align: center;  padding-top: 12px;" >  LEMBAGA SERTIFIKASI <br> BARISTAND INDUSTRI SURABAYA</h5>
	</div>
</div>


</body>
</html>