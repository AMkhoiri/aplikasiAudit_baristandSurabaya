<!DOCTYPE html>
<html>
<head>
	
 	<?php echo $__env->make('auditor.headerauditor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	
	<title></title> 
</head>
<body>
<div class=" container-fluid" style=" font-size: 12px ; " > 
	


<div class="breadcrumb " style="margin-bottom: 5px; margin-top: 5px; " >
  <div class="container-fluid">
   <div class="row">
     <div class="col-md-8  " style="font-size: 20px; font-weight: bold; color: #676767; "> <span class="fa fa-file-archive-o" > </span> Arsip Data</div>
      <div class="col-md-4"  >

       <form action="<?php echo e(route('auditordataarsip')); ?>" method="post">
           <?php echo e(csrf_field()); ?> 
        <div class="row">
          
          <div class="col-md-8" style=" text-align: right !important; padding-right: 0;">
            <div class="form-group" style=" display: inline;">
              
              <select class="form-control-sm" style=" width: 240px; border: none; font-size: 13px;" name="tahun_audit" required>
                <option value="" selected>Pilih tahun audit..........</option>
              <?php $__currentLoopData = $periode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($p->tahun_audit); ?>"><?php echo e($p->tahun_audit); ?></option>           
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </select>
            </div>
          </div>
          <div class="col-md-4" style="margin-left: 0">
            <button type="submit" style="display: inline; padding: 6px 16px 6px 16px;   font-size: 12px; background-color: #3993d0; color: #fff;" class="btn btn-sm "><span class="fa fa-search" > Cari Data </span></button>
          </div>
        </div>
       </form>

      </div>
    </div>
   </div>
  </div> 


</div>

</body>
<div style="margin-bottom: 500px;" ></div>
</html>
  <?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>