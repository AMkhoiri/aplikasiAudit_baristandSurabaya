<?php $__env->startSection('content'); ?>

<div class="container ">

     <div class="panel panel-default" style=" border-radius: 20px; " >
        <div class="panel-heading"> <span class=" btn " > <a href="#" style=" text-decoration: none; border-radius: 20px;" > <span class="fa fa fa-bullhorn " style=" font-size:22px; margin-right: 5px; " >  </span>  <b> Mungkin Ini Penting!</b> </a></div>
            <div class=" panel-body " > 

                <?php $__empty_1 = true; $__currentLoopData = $pengumuman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                   <li> <i style=" font-size: 10px; " > <?php echo e(\Carbon\Carbon::parse ($p->updated_at)->format('d - M - Y')); ?> </i>  &emsp; <?php echo e($p->pengumuman); ?> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p style="margin-left: 40px; " > Tidak Ada Pengumuman </p> 

                <?php endif; ?>

            </div>
    </div>


    <div class="row">

        <div class=" col-sm-4 " >  </div>

        <div class="col-sm-4">

                <div class=" pann"   style=" margin-top: 30px; margin-left: 10px; margin-right: 10px; " >
            <div class="panel panel-default " style=" border-radius: 0px ; " >
                  
                <div class="panel-heading" style="text-align: center; margin-top: 12px;font-size: 11px;  padding-bottom:12px;" >

                    <img   style=" max-width: 70px;  "  src=" <?php echo e(asset('audit/img/bisby.png')); ?>">
                    <br>Audit Internal

                </div>

                <div class="panel-body" style="" >

                    <p style=" text-align: center; " > Insert Your Account </p><br>
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo e(csrf_field()); ?>


                         <div class="form-group has-feedback <?php echo e($errors->has('email') ? ' has-error' : ''); ?>" style=" margin-right: 18px; margin-left: 18px; " >
                            

                            
                                <input id="email" type="text" class="form-control"   name="email" value="<?php echo e(old('email')); ?>" placeholder="Username" required autofocus>

                                <i class="fa fa-user form-control-feedback"></i>

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            
                        </div>

                        <div class=" form-group has-feedback <?php echo e($errors->has('password') ? ' has-error' : ''); ?>"  style=" margin-right: 18px; margin-left: 18px; ">
                            

                            
                                <input id="password" type="password" class="form-control" name="password" placeholder="Password" required >
                              <i class="fa fa-lock form-control-feedback"></i>
                              

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            
                        </div>
                        

                       

                        <div style=" text-align: center; margin-right: 18px; margin-left: 18px; " >  
                            <button  style="width: 100%; background-color: #007AFF  ; color: white" type="submit" class="btn btn-sm">
                                Log In
                            </button>
                        </div>

                        <br>
                               
                                

                         <div style=" font-size: 10px; margin-right: 18px; margin-left: 18px; " > *Masukkan Akun sesuai dengan akses yang anda inginkan!</div>
                    </form>
                </div>
            </div>
                   </div>
        </div>

         <div class=" col-md-4 " >  </div>

    </div>
</div>
<?php $__env->stopSection(); ?>




<script>
    var msg = '<?php echo e(Session::get('alert')); ?>';
    var exist = '<?php echo e(Session::has('alert')); ?>';
    if(exist){
      alert(msg);
    }
  </script>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>