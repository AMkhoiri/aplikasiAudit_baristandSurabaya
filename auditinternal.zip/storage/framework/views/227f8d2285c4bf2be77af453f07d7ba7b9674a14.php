<!DOCTYPE html>
<html>
<head>

	<?php echo $__env->make('layout.head-css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->make('auditee.headerauditee', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<title>Form Tindakan</title>
</head>
<body>


<div class="container" style="margin-top: 20px; font-size: 12px; "><br>

    
    <h5 style=" text-align: center; " >EDIT TINDAKAN</h5><br>


<table class="table table-responsive table-striped table-bordered"  >
	
    <tr>
      <th style="text-align:center;">No LKS</th>
      <th style="text-align:center;">Deskripsi Ketidaksesuaian</th>
      <th style="text-align:center;">Dokumen Acuan</th>
          <th style="text-align:center;">Tidak Sesuai Dengan SNI ISO/IEC 17065:2012 Klausul</th>
          <th style="text-align:center;">Tidak Sesuai Dengan SNI ISO/IEC 17021-1:2015 Klausul</th>
          <th style="text-align:center;">Tidak Sesuai Dengan SNI ISO/IEC 17021-1:2017 Klausul</th>
          <th style="text-align:center;">Tidak Sesuai Dengan (Dokumen SMM)</th>
    </tr>

    <tr>  
      <td style="text-align:center; width: 45px; "> <?php echo e($lks->nolks); ?> </td>
      <td style="width: 280px;">  <?php echo e($lks->deskripsi); ?></td>
      <td style="width: 100px;"> <?php echo e($lks->acuan); ?> </td>
      <td style=""> <?php echo e($lks->iec_2012); ?> </td>
      <td style="">  <?php echo e($lks->iec_2015); ?> </td>
      <td style="">   <?php echo e($lks->iec_2017); ?></td>
      <td style="text-align:center;">   <?php echo e($lks->smm); ?></td>
   </tr>
  
  </table>
</div>



<div class="container" style="margin-top: 80px; font-size: 12px; ">
  <form role="form" class="row" action="<?php echo e(route ('updatetindakan', $tindakan->id_tindakan)); ?>" method="post" >
    <?php echo e(csrf_field()); ?>


    <div class="col-md-6">
      <div class="form-group">
        <label for="akar"><b>Akar Permasalahan : </b></label>
        <textarea cols="50" rows="6" class="form-control" name="akar" id="akar" required><?php echo e($tindakan -> akar); ?></textarea><br>
        <label for="dilakukan"><b>Tindakan Yang Akan Dilakukan : </b></label>
        <textarea cols="50" rows="6" class="form-control" name="dilakukan" id="dilakukan" required><?php echo e($tindakan ->dilakukan); ?></textarea>
      </div>

        <?php  $nama= $auditee->nama;  ?>
        
    </div>

    <input type="hidden" class="form-control" id="pengirim_tindakan" value="<?php echo e($nama); ?>" name="pengirim_tindakan">

    <div class="col-md-6">
      <div class="form-group">
        <label for="pencegahan"><b>Tindakan Pencegahan : </b></label>
        <textarea cols="50" rows="6" class="form-control" name="pencegahan" id="pencegahan" required><?php echo e($tindakan -> pencegahan); ?></textarea><br><br>
          <button type="submit" class="btn btn-primary btn-sm "><span class=" fa fa-save " >  Simpan</span></button>
          <input type="hidden" name="_method" value="PUT">
       
      </div>

      </div>
    </div>
  </form>
</div>


</body>
</html>
<?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>