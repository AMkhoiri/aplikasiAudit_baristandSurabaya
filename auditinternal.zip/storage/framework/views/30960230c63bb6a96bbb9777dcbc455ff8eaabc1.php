<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Audit Internal - Landing Page</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/img/favicon.ico" />
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v5.13.0/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="<?php echo e(asset('audit/landing/css/styles.css')); ?>" rel="stylesheet" />

            <link rel="icon" type="image/png" href="<?php echo e(asset('audit/img/favicon.png')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('audit/admin/assets/css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('audit/admin/assets/css/font-awesome.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('audit/admin/assets/css/themify-icons.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('audit/admin/assets/css/metisMenu.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('audit/admin/assets/css/owl.carousel.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('audit/admin/assets/css/slicknav.min.css')); ?>">
        <!-- amchart css -->
        <link rel="stylesheet" href="https://www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
        <!-- others css -->
        <link rel="stylesheet" href="<?php echo e(asset('audit/admin/assets/css/typography.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('audit/admin/assets/css/default-css.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('audit/admin/assets/css/styles.css')); ?>">
        
        <!-- modernizr css -->
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">

        <link href="https://fonts.googleapis.com/css2?family=Kumbh+Sans:wght@300;400&display=swap" rel="stylesheet">


        <script src="<?php echo e(asset('audit/admin/assets/js/vendor/modernizr-2.8.3.min.js')); ?>"></script>

<style>
    .btn:hover{
        box-shadow:3px 4px 4px #919191;
    }
</style>

    </head>
    <body id="page-top">
        <!-- Navigation-->

        <!-- Masthead-->
        <header class="masthead text-white text-center" style="background-color: #2E86C1; background: linear-gradient(to right, #2E86C1, #1cb5e0); padding-top: 0; ">
            <div class="container d-flex align-items-center flex-column">
                <!-- Masthead Avatar Image-->
                <img class="masthead-avatar mb-1" src=" <?php echo e(asset('audit/img/favicon.png')); ?>" alt="" />
                <!-- Masthead Heading-->
                <h1 class="masthead-heading text-uppercase mb-0" style="font-size: 45px;">Audit Internal</h1>
                <!-- Icon Divider-->
                <div class="divider-custom divider-light">
                  
                    
                    <div class="divider-custom-line"></div>
                     <div class="divider-custom-line"></div>
                </div>
                <!-- Masthead Subheading-->
                <p class="masthead-subheading font-weight-bold mb-0" style=" color: #fff;" >Balai Riset Dan Standardisasi Industri Surabaya</p>
                 <div class="submit-btn-area" style="margin-bottom: 0px;">
                  <a href="<?php echo e(route('login')); ?> "> <button  class="btn "  style="width: 200px; margin-top: 20px;" > 
                      Login &nbsp;&nbsp; <span class="ti-arrow-right" > </span>
                  </button></a>
                 </div>
            </div>
        </header>
        <!-- Portfolio Section-->
        <section class="page-section portfolio" id="portfolio">
            <div class="container">
                <!-- Portfolio Section Heading-->
                <h2 class="page-section-heading text-center text-uppercase text-secondary mb-0 mt-0" style="font-size: 25px;">Rekapitulasi Sementara</h2>


                <div class="container-fluid"  style="font-size: 12px; "> <br>

 <div class="card">
      <div class="card-body">
        
        <div class="single-table">
             
                  <table class="table table-hover text-center" style="font-size: 12px !important; ">
                    <thead class="text-uppercase">
    
         <tr  >
              <th style="text-align:center">NO</th> 
              <th style="text-align:center">Nama</th>
              <!-- <th style="text-align:center">Jenis Kelamin</th> -->
              <th style="text-align:center">NIP</th>
              <th style="text-align:center">SIE</th>
              <th style="text-align:center">Jabatan</th>
              <!-- <th style="text-align:center">Email</th> -->
              <th style="text-align:center">Aksi</th>   
        </tr>

</thead>
 
    
        <tr>
              <td style="text-align:center">  </td>
              <td style=""> </td>

              <td style="text-align:center">}  </td>
              <td style="">   </td>
              <td style=""> </td>
              <td style="text-align:center; width: 173px; " >

                <div class="row" > 
                    <div class=" col-md-6 " >     
                    </div>
                    <div class=" col-md-6 " > 
                    </div>
              </div>
                 
                  
              </td>

        </tr>

  </table>


  <br><br> <br><br>
</div>
</div>
</div>
 </div>

</div>
</section>







        <!-- Footer-->
      
        <!-- Bootstrap core JS-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.bundle.min.js"></script>
        <!-- Third party plugin JS-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
        <!-- Contact form JS-->
        <script src="assets/mail/jqBootstrapValidation.js"></script>
        <script src="assets/mail/contact_me.js"></script>
        <!-- Core theme JS-->
        <script src="<?php echo e(asset('audit/landing/js/scripts.css')); ?>"></script>
    </body>
</html>
