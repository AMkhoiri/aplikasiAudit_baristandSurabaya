<!DOCTYPE html>
<html>
<head>

	<?php echo $__env->make('layout.head-css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->make('auditee.headerauditee', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<title>Form Tindakan</title>


<style>
  textarea { font-size: 13px !important; }
</style>
</head>
<body>

<div class="container-fluid" style=" font-size: 12px;">

    

<div class="breadcrumb" style="margin-bottom: 5px;" >
  <div class="container-fluid">
     <div  style="font-size: 20px; color: #3993d0; font-weight: bold; "> <span class="fa fa-file" > </span> Laporan Ketidaksesuaian </div>
   </div>
  </div> 



<table class="table table-responsive table-striped table-bordered"  >
	
    <tr>
      <th style="text-align:center;">No LKS</th>
      <th style="text-align:center;">Deskripsi Ketidaksesuaian</th>
      <th style="text-align:center;">Dokumen Acuan</th>
          <th style="text-align:center;">SNI ISO/IEC 17065:2012 Klausul</th>
          <th style="text-align:center;"> SNI ISO/IEC 17021-1:2015 Klausul</th>
          <th style="text-align:center;">SNI ISO/IEC 17021-1:2017 Klausul</th>
          <th style="text-align:center;">(Dokumen SMM)</th>
    </tr>

    <tr>  
      <td style="text-align:center; width: 45px; "> <?php echo e($lks->nolks); ?> </td>
      <td style="width: 300px;">  <?php echo e($lks->deskripsi); ?></td>
      <td style="width: 160px;"> <?php echo e($lks->acuan); ?> </td>
      <td style=""> <?php echo e($lks->iec_2012); ?> </td>
      <td style="">  <?php echo e($lks->iec_2015); ?> </td>
      <td style="">   <?php echo e($lks->iec_2017); ?></td>
      <td style="text-align:center;">   <?php echo e($lks->smm); ?></td>
   </tr>
  
  </table>
</div>

<div class="container-fluid" style="font-size: 12px;" >
    

<div class="breadcrumb" style="margin-bottom: 5px;" >
  <div class="container-fluid">
     <div  style="font-size: 20px; color: #3993d0; font-weight: bold; "> <span class="fa fa-pencil" > </span> Edit Tindakan Perbaikan </div>
   </div>
  </div> 







<div class="breadcrumb" style="margin-bottom: 5px;" >
  <form role="form"  action="<?php echo e(route ('updatetindakan', $tindakan->id_tindakan)); ?>" method="post"  enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>


<div class="row">
    <div class="col-md-4">
      <div class="form-group">
        <label for="akar"><b>Akar Permasalahan  </b></label>
        <textarea cols="80" rows="7" class="form-control" spellcheck="false" placeholder="Tulis Akar Permasalahan" name="akar" id="akar" required> <?php echo e($tindakan->akar); ?> </textarea><br>
       
      </div>
    </div>

    <div class="col-md-4">
      <div class="form-group">
       <label for="dilakukan"><b>Tindakan Yang Akan Dilakukan  </b></label>
        <textarea cols="80" rows="7" class="form-control" spellcheck="false" placeholder="Tulis Tindakan Yang Akan Dilakukan" name="dilakukan" id="dilakukan"  required> <?php echo e($tindakan->dilakukan); ?></textarea>
      </div>
    </div>

    <div class="col-md-4">
      <div class="form-group">
        <label for="pencegahan"><b>Tindakan Pencegahan  </b></label>
        <textarea cols="80" rows="7" class="form-control" spellcheck="false" placeholder="Tulis Tindakan Pencegahan" name="pencegahan" id="pencegahan" required> <?php echo e($tindakan->pencegahan); ?></textarea><br>

       </div>
      </div>

     <?php  $nama= $auditee->nama;  ?>
    <input type="hidden" class="form-control" id="pengirim_tindakan" value="<?php echo e($nama); ?>" name="pengirim_tindakan">


  </div>
  <div class="row">
    <div class="col-md-6">
      <label for="filebukti"><b>Sertakan File Bukti</b> (Ekstensi File: pdf/docx/doc/jpg/jpeg/png/zip/rar  max size: 2mb) </label>
      <input type="file" id="filebukti" class="form-control-file" name="file" style="  " > <?php echo e($tindakan->title); ?>


    </div>

    <div class="col-md-6" style="text-align: right;">
       <a  class="btn btn-sm btn-secondary " href="<?php echo e(url ('/auditee/daftartindakan')); ?> " style=" width: 120px; margin-right: 10px;" ><span class=" fa fa-arrow-left " >  Batal</span></a>
        <button type="submit" class="btn btn-primary btn-sm " style=" width: 120px; " ><span class=" fa fa-save " > Simpan</span></button>
    </div>
  </div>

           <?php if(count($errors) > 0): ?>
          <br><div class="alert alert-danger  " style=" align-content: left; text-align: left; font-size: 13px;" >
              
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php echo e($error); ?>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
          </div>
        <?php endif; ?>  
     
       
      <input type="hidden" name="_method" value="PUT">
  </form>

</div>
 </div>


</body>



<script>
    var msg = '<?php echo e(Session::get('alert')); ?>';
    var exist = '<?php echo e(Session::has('alert')); ?>';
    if(exist){
      alert(msg);
    }
  </script>

</html>
<?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>