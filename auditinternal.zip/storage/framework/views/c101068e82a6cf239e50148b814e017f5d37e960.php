<!DOCTYPE html>
<html>
<head><?php echo $__env->make('layout.head-css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<title>BISBY - Audit Internal</title>
</head>
<body>
	<?php echo $__env->make('admin.headeradmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<br><br><br><br><br>


<div class="container " style="font-size: 12px; ">  

	
	<h5 style=" text-align: center; " > DATA PENGUMUMAN</h5> <br><br>

	<div class="table-responsive">
	<table class="table  table-bordered table-striped " >  

		<tr>
			
			<th style=" text-align: center; width: 80px; " >No</th>
			<th style=" text-align: center; " >Isi Pengumuman</th>
			<th style=" text-align: center; width: 150px; " >Tanggal Dibuat</th>
			<th style=" text-align: center; width: 140px; " >Status</th>
			<th style=" text-align: center;width: 160px;  " >Aksi</th>
		</tr>

		<?php $no = 0;?>
 
		<?php $__currentLoopData = $pengumuman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php $no++ ;?> 
	
			<tr>
				
				<td style=" text-align: center; "> <?php echo e($no); ?></td>
				<td> <?php echo e($p->pengumuman); ?></td>
				<td style=" text-align: center; "> <?php echo e(\Carbon\Carbon::parse ($p->created_at)->format('d - M - Y')); ?></td>
				<td style=" text-align: center; "> <?php echo e($p->status); ?></td>
				<td style=" text-align: center; ">
					<div class="row " >  
						<div class=" col-md-6 " > 

							<?php if($p->status==NULL): ?>

								<form class="form-horizontal" action="<?php echo e(route('publishpengumuman',$p->id)); ?>" method="post">
			                    	<?php echo e(csrf_field()); ?>     

			                             <input type="hidden" class="form-control" id="pengumuman" name="pengumuman" value="Published">
			                        	<button type="submit" style="width: 68px; font-size: 9px; " onclick="return confirm('Anda Yakin Untuk Mem-Publish Pengumuman Ini ?')"  class="btn btn-sm btn-success"  ><span class=" fa fa-arrow-up " >  Publish</span></button>

			                        <input type="hidden" name="_method" value="PUT">
		                    </form>
								
							<?php endif; ?>
							

						</div>

						<div class=" col-md-6 " > 
							 <form action=" <?php echo e(route('hapuspengumuman',$p->id)); ?>"  method="post" >     
		                          <input  class="btn btn-danger btn-sm " style="width: 58px; font-size: 9px; "   onclick="return confirm('Anda Yakin Untuk Menghapus Pengumuman Ini ?')" type="submit" name="submit" value="Hapus">
		                          <?php echo e(csrf_field()); ?>          
		                          <input type="hidden" name="_method" value="DELETE" >
                    		 </form> 

						</div>

					</div>


				</td>
			</tr>


		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</table>
	</div>

	<br> <hr> <br><br>

		<h5 style=" text-align: center; " > BUAT PENGUMUMAN</h5> <br><br>
	<div class=" row " >  

		<div class="col-md-3" > 
			
		</div>
				

		<div class="col-md-6 " >  
			<div class=" card " > 
				<div class=" card-body " > 
					<div class=" card-title " > <p>Tulis Sebuah Pengumuman, Seperti Tanggal Terakhir Perbaikan, Waktu Perpanjangan, Atau Apapun!. Setelah Anda Publish, Isi Pengumuman Akan Ditampilkan Di Halaman Login User.</p>
					</div>

						<form class="form-horizontal" action="<?php echo e(route ('storepengumuman')); ?>" method="post">
					<?php echo e(csrf_field()); ?>


			<label class="control-label " for="pengumuman"> <b style=" font-size: 12px; " > Tulis Sesuatu  : </b></label>
					<textarea cols="50" rows="5" class="form-control" id="catver" placeholder="Tulis Pengumuman" name="pengumuman" required ></textarea>
					<br>

					<div style=" text-align: right; " >  
						<button type="submit"  class="btn btn-success btn-sm" style=" width: 80px;font-size: 12px;  " >  Simpan</button>
					</div>
			</form>
				</div>
			</div>
		</div>



		<div class="col-md-3" > 
			
		</div>

	</div>



</div>

<br><br><br><br><br>
</body>

<script>
    var msg = '<?php echo e(Session::get('alert')); ?>';
    var exist = '<?php echo e(Session::has('alert')); ?>';
    if(exist){
      alert(msg);
    }
  </script>



</html>
<?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>