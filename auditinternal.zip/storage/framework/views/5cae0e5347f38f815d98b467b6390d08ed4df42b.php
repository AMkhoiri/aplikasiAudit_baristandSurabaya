<!DOCTYPE html>
<html>
<head>

 <?php echo $__env->make('layout.head-css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <?php echo $__env->make('auditor.headerauditor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<title>Daftar Pertanyaan</title>
</head>
<body>
	<br><br>
	<div class="container" style=" font-size: 12px  " > 

		<h5 style="text-align: left; " >Area Audit :  <br>

       <?php if(Auth::user()->lokasi==NULL): ?>
    <i style=" color: red; " > Akun Anda Tidak Aktif, Silahkan Hubungi Admin !</i>
    <?php else: ?>
    <?php echo e(Auth::user()->lokasi); ?>

    <?php endif; ?>

    </h5> 
		<h5 class=" text-center " >DAFTAR PERTANYAAN</h5> 
        <br>
            <div style=" text-align: right; " >  

          <?php if(Auth::user()->lokasi==!NULL): ?>
            
            <a href="<?php echo e(route('tambahpertanyaan')); ?>"><button class="btn btn-primary btn-sm " style=" width: 130px; font-size: 11px;  "  > <span class=" fa fa-plus " >  Tambah Pertanyaan</span></button></a>

            <a href="<?php echo e(route('cetakpertanyaan')); ?>"><button class="btn btn-success btn-sm " style="width: 130px; font-size: 11px; "  > <span class=" fa fa-print " >  Cetak Pertanyaan</span></button></a>

            <?php else: ?>
            
          <?php endif; ?>
            
       </div>

        <br>
        <div class="table-responsive">

		<table class="table  table-striped table-bordered  " style=" "  >
    <tr>
      	<th class=" text-center ">No</th>
        <th class=" text-center ">Penulis</th>
      	<th class=" text-center ">Pertanyaan</th>
      	<th class=" text-center " style="width: 100px; ">Kategori</th>
      	<th class=" text-center ">Catatan</th>
      	<th class=" text-center " style="width: 130px; " >LKS</th>
      	<th class=" text-center " style="width: 100px; ">Aksi</th>   
    </tr>

      <?php $no = 0;?>
    <?php $__currentLoopData = $pertanyaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php $no++ ;?>


    <tr>  
      <td class="  text-center " ><?php echo e($no); ?></td>
       <td class=" text-center "><?php echo e($pr->penulis); ?></td>
      <td class="  "> <?php echo $pr -> pertanyaan; ?> </td>
      <td class=" text-center "> <?php echo e($pr -> kategori); ?> </td>
      <td class="  "> <?php echo e($pr -> catatan); ?> </td>
      <td   class=" text-center ">

        <?php if( $pr->kategori=="NOK"): ?>
          <?php if( $pr->status==NULL): ?>
            <a href="<?php echo e(route('buatlks',$pr->id)); ?>"><button class="btn btn-info btn-sm" style=" width: 75px; font-size: 10px;"  > <span class=" fa fa-pencil " >  Buat LKS</span></button></a>
          <?php else: ?>
            <?php echo e($pr ->status); ?>


          <?php endif; ?>  
        <?php else: ?>    
        <h6></h6>
        <?php endif; ?>
        
      </td>

      <td class=" text-center ">
           <?php if( $pr->status==NULL): ?>

          	 <a href="<?php echo e(route('editpertanyaan',$pr->id)); ?>"><button class="btn btn-primary btn-sm" style="width: 60px; font-size: 10px; "> <span class=" fa fa-edit " > Edit</span></button></a>
             <br><br>
        
             <form action="<?php echo e(route('hapuspertanyaan',$pr->id)); ?>" method="post">
                <input class="btn btn-danger btn-sm" style="width: 60px; font-size: 10px;" onclick="return confirm('Anda yakin untuk Menghapus pertanyaan ini ??')" type="submit" name="submit"   value="Hapus"> 

                
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="_method" value="DELETE">
             </form>

             <?php else: ?>
             <?php endif; ?>
       </td>
    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
  </table>

  </div>

  <br><br>


</div>

</body>
<br><br><br>




<script>
    var msg = '<?php echo e(Session::get('alert')); ?>';
    var exist = '<?php echo e(Session::has('alert')); ?>';
    if(exist){
      alert(msg);
    }
  </script>
  </html>
  <?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>