<!DOCTYPE html>
<html>
<head>

	<?php echo $__env->make('layout.head-css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->make('admin.headeradmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<title> Data kepala balai </title>
</head>
<body>


		 <br><br><br><br><br>
<div class="container"  style="font-size: 14px; "> 

      <h5 style="text-align: center; " >KEPALA BALAI</h5> 
        <br><br>

  <table class="table  table-striped table-bordered table-hover "  >

     <tr  >
        <th style="text-align:center">Username</th>
        <th style="text-align:center">Password</th>  
        <th style="text-align:center">Aksi</th> 
       
    </tr>

  <?php $__currentLoopData = $kepala; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  
    <tr>  
        <td style="text-align:center"> <?php echo e($a->username); ?> </td>
        <td style="text-align:center">  <?php echo e($a->pass); ?></td>
        <td style="text-align:center">  

          <form action=" <?php echo e(route('hapususer3',$a->id)); ?>"  method="post" >     
                          <input  class="btn btn-danger btn-sm " style="width: 55px; font-size: 11px; "   onclick="return confirm('Anda Yakin Untuk Menghapus User <?php echo e($a->username); ?> ?. Setelah terhapus anda bisa me-registrasi ulang.')" type="submit" name="submit" value="Hapus">
                          <?php echo e(csrf_field()); ?>          
                          <input type="hidden" name="_method" value="DELETE" >
                      </form>

        </td>
       
    </tr>
    
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </table>

</div>
<br><br><br><br><br><br><br>

</body>
</html>
<?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>