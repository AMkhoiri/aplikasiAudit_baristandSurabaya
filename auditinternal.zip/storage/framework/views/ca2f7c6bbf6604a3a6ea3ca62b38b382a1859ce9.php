
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Administrator Audit Internal</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="<?php echo e(asset('audit/img/favicon.png')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('audit/admin/assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('audit/admin/assets/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('audit/admin/assets/css/themify-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('audit/admin/assets/css/metisMenu.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('audit/admin/assets/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('audit/admin/assets/css/slicknav.min.css')); ?>">
    <!-- amchart css -->
    <link rel="stylesheet" href="https://www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
    <!-- others css -->
    <link rel="stylesheet" href="<?php echo e(asset('audit/admin/assets/css/typography.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('audit/admin/assets/css/default-css.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('audit/admin/assets/css/styles.css')); ?>">
    
    <!-- modernizr css -->
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">

    <link href="https://fonts.googleapis.com/css2?family=Kumbh+Sans:wght@300;400&display=swap" rel="stylesheet">


    <script src="<?php echo e(asset('audit/admin/assets/js/vendor/modernizr-2.8.3.min.js')); ?>"></script>

 
         <?php echo $__env->yieldContent('css'); ?>
  
  <style>
      
a{
    text-decoration: none;
    color: #676666;
}

a:hover{
    text-decoration: none;
}
 
  </style>
   
</head>

<body>

    <!-- preloader area start -->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- preloader area end -->
    <!-- page container area start -->
    <div class="page-container">
       
    <?php echo $__env->make('admin/layout/bsidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!-- main content area start -->
        <div class="main-content">
            <!-- header area start -->
            <div class="header-area">
                <div class="row align-items-center">
                    <!-- nav and search button -->
                    <div class="col-md-6 col-sm-8 clearfix">
                        <div class="nav-btn pull-left">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                    </div>
                    <!-- profile info & task notification -->
                    <div class="col-md-6 col-sm-4 clearfix">
                        <ul class="notification-area pull-right">
                            <li id="full-view"><i class="ti-fullscreen"></i></li>
                            <li id="full-view-exit"><i class="ti-zoom-out"></i></li>
                            <li class="settings-btn">
                                <i class="ti-user"></i>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- header area end -->
                <?php echo $__env->yieldContent('navigasi'); ?>
            <div class="main-content-inner">
                <div class="row">
                   <?php echo $__env->yieldContent('isi'); ?>
                </div>
            </div>
        </div>
        <!-- main content area end -->
        <!-- footer area start-->
        <footer>
            <div class="footer-area" >
               
                <p style="font-family: 'Kumbh Sans', sans-serif;">Made with <span style="color: #ff3377" >❤</span> by  <a href="mailto:ahmad.m.khoiri@gmail.com">ahmad.m.khoiri@gmail.com</a> </p>
            </div>
        </footer>
        <!-- footer area end-->
    </div>
    <!-- page container area end -->

    <!-- offset area start -->



      <div class="offset-area">
        <div class="offset-close"><i class="ti-close"></i></div>
        <ul class="nav offset-menu-tab">
            
            <li><a data-toggle="tab" href="#settings">User Account</a></li>
        </ul>
        <div class="offset-content tab-content">
 
            <div id="settings" class="tab-pane fade in show active">
                <div class="offset-settings">
                    <div class="settings-list">
                        <div class="s-settings">
                            <div class="s-sw-title">
                                <h5><?php echo e(Auth::user()->username); ?></h5>
                                <div class="s-swtich">
                                      <a href="<?php echo e(url('/logout')); ?>"
                                                            onclick="event.preventDefault();
                                                           document.getElementById('logout-form').submit();" id="links" class="nav-item nav-link"><span class="fa fa-sign-out" ></span> Logout </a>
                                      <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                                                    <?php echo e(csrf_field()); ?>

                                      </form> 
                                      
                                </div>
                            </div>
                            <p></p>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
   
   

    <!-- offset area end -->
    <!-- jquery latest version -->
    <script src="<?php echo e(asset('audit/admin/assets/js/vendor/jquery-2.2.4.min.js')); ?>"></script>

    <script src="<?php echo e(asset('audit/admin/assets/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('audit/admin/assets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('audit/admin/assets/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('audit/admin/assets/js/metisMenu.min.js')); ?>"></script>
    <script src="<?php echo e(asset('audit/admin/assets/js/jquery.slimscroll.min.js')); ?>"></script>
    <script src="<?php echo e(asset('audit/admin/assets/js/jquery.slicknav.min.js')); ?>"></script>


    <!-- others plugins -->
    <script src="<?php echo e(asset('audit/admin/assets/js/plugins.js')); ?>"></script>
    <script src="<?php echo e(asset('audit/admin/assets/js/scripts.js')); ?>"></script>

    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <?php echo $__env->make('sweet::alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->yieldContent('js'); ?>
</body>

</html>

