<!DOCTYPE html>
<html>
<head>

	<?php echo $__env->make('layout.head-css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->make('admin.headeradmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<title> Data Pegawai </title>
</head>
<body>


		 <br><br><br><br><br>
<div class="container"  style="font-size: 12px; "> 

      <h5 style="text-align: center; " >DATA AUDITEE</h5> 
        <br><br>
  
  <div class="table-responsive">
  <table class="table  table-striped table-bordered  table-hover"  >

     <tr >
        <th style="text-align:center">NO</th>
        <th style="text-align:center">Nama</th> 
        <th style="text-align:center">Lokasi Auditee</th>
        <th style="text-align:center">Username</th>
        <th style="text-align:center">Password</th>  
        <th style="text-align:center">Status</th>
        <th style="text-align:center">Aksi</th>
    </tr>


    <?php $no = 0;?>
   <?php $__currentLoopData = $auditee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $no++ ;?> 


    <tr>  
        <td style="text-align:center"> <?php echo e($no); ?> </td>    
        <td style=" width: 240px; "> <?php echo e($a->nama); ?>  </td>
        <td style="width: 300px;"> <?php echo e($a->lokasi_auditee); ?> </td>
        <td style="text-align:center">  <?php echo e($a->username); ?></td>
        <td style="text-align:center">  <?php echo e($a->pass); ?></td>

        <td style="text-align:center"> 

           <?php if( $a->lokasi == NULL & $a->username == !NULL): ?>
            Belum Aktif

          <?php elseif( $a->username == NULL): ?>
          Belum Di-Registrasi
                
          <?php else: ?> 
          
          Aktif  
          <?php endif; ?>


        </td>

        <td style="text-align:center; width: 180px; "> 
          <?php if( $a->username == !NULL): ?>

            <div class="row" > 

                <div class=" col-md-6 " >  

                  <?php if($a->lokasi == NULL): ?>

                     <form class="form-horizontal" action="<?php echo e(route('syncauditee',$a->id)); ?>" method="post">
                    <?php echo e(csrf_field()); ?>      
                        <input type="hidden" class="form-control" id="status" name="lokasi" value="<?php echo e($a->lokasi_auditee); ?>">
                                 
                        <button type="submit" style="width: 62px; font-size: 8px; "   class="btn btn-sm btn-success"  >Aktifkan</button>

                        <input type="hidden" name="_method" value="PUT">
                    </form>

                    <?php else: ?>

                     <form class="form-horizontal" action="<?php echo e(route('asyncauditee',$a->id)); ?>" method="post">
                    <?php echo e(csrf_field()); ?>      
                       
                                 
                        <button type="submit" style="width: 62px; font-size: 8px;" onclick=" return confirm('Anda Yakin Untuk Me-Nonaktifkan Akun Ini ? ') "  class="btn btn-sm btn-"  >Non-Aktifkan</button>

                        <input type="hidden" name="_method" value="PUT">
                    </form>

                    
                  <?php endif; ?>
                     
                </div>


                <div class=" col-md-6 " > 
                        <form action=" <?php echo e(route('hapususer2',$a->id)); ?>"  method="post" >     
                                      <input  class="btn btn-danger btn-sm " style="width: 62px; font-size: 8px;"   onclick="return confirm('Anda Yakin Untuk Menghapus User <?php echo e($a->username); ?> ?. Setelah terhapus, anda bisa me-regristrasi ulang.')" type="submit" name="submit" value="Hapus">
                                      <?php echo e(csrf_field()); ?>          
                                      <input type="hidden" name="_method" value="DELETE" >
                        </form>
                </div>

               </div>
             <?php endif; ?>         
         </td>
             
    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
  </table>
  </div>
  <br><br>

   <i>*Username Dan Password Dapat Digunakan Setelah Diaktifkan</i> 
</div>
        <br><br><br><br><br><br>

</body>

<script>
    var msg = '<?php echo e(Session::get('alert')); ?>';
    var exist = '<?php echo e(Session::has('alert')); ?>';
    if(exist){
      alert(msg);
    }
  </script>
</html>
<?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

