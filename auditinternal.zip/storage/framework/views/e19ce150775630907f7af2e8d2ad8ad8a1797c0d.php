
<?php 

use App\catatan;

 ?>

<!DOCTYPE html>
<html>
<head>


 <?php echo $__env->make('layout.head-css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <?php echo $__env->make('auditor.headerauditor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <title>Tindakan Perbaikan</title>
</head>

<body>

<div class="container" style="font-size: 12px; " ><br><br>
  <h5 style="text-align: left; " >Area Audit :  <br>

     <?php if(Auth::user()->lokasi==NULL): ?>
    <i style=" color: red; " > Akun Anda Tidak Aktif, Silahkan Hubungi Admin !</i>
    <?php else: ?>
    <?php echo e(Auth::user()->lokasi); ?>

    <?php endif; ?>

  </h5><br>
    <h5 style="text-align: center ">TINDAKAN PERBAIKAN</h5><br>

<div class="table-responsive">
    <table class="table  table-striped table-bordered"  >

      <tr>

        <th style="text-align:center;">No LKS</th>
        <th style="text-align:center;">Dokumen Acuan|Deskripsi Ketidaksesuaian</th>
        <th style="text-align:center;">Tidak Sesuai Dengan</th>
        <th style="text-align:center;">Tindakan</th>
         <th style="text-align:center;">File Bukti</th>
         <th style="text-align:center;">Catatan</th>
         <th style="text-align:center;">Aksi</th>

      </tr>

    
    <?php $__currentLoopData = $tindakanlks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

    <tr>  
      <td style="text-align:center; width: 20px;"> <?php echo e($lk ->nolks); ?> </td>
      <td style="width: 150px; text-align:left;"> 
          <b> Dokumen Acuan: </b> <br><?php echo e($lk ->acuan); ?><br><br>
          <b> Deskripsi Ketidaksesuaian: </b> <br><?php echo e($lk -> deskripsi); ?>

      </td>
      <td style="width: 140px;"><b>SNI ISO/IEC 17065:2012 Klausul :</b><br> <?php echo e($lk -> iec_2012); ?> <br>
                                   <b>ISO/IEC 17021-1:2015 Klausul :</b><br> <?php echo e($lk -> iec_2015); ?> <br>
                                   <b>ISO/IEC 17021-3:2017 Klausul :</b><br> <?php echo e($lk -> iec_2017); ?> <br>
                                   <b>Dokumen SMM :</b><br> <?php echo e($lk -> smm); ?> </td>


      <td  style="width: 180px;">
        <!-- <a href="<?php echo e(route('tindakan',$lk->id)); ?>"><button class="btn btn-primary btn-sm" >Lihat Tindakan</button></a> -->
       <b> Akar Permasalahan : </b><br><?php echo $lk -> akar; ?><br><br>
        <b> Tindakan Dilakukan : </b><br><?php echo $lk ->dilakukan; ?><br><br>
         <b> Tindakan Pencegahan : </b><br><?php echo $lk -> pencegahan; ?><br><br>
      </td>
       <td class="  text-center " style="width: 90px; "  > <p class=" fa fa-file-o" >  </p> &ensp;

         <?php echo e($lk ->title); ?> <br><br> 

          <?php if($lk->title == !NULL): ?>
          <a href="<?php echo e(route ('downloadfile', $lk->id_tindakan)); ?>" class=" btn btn-info btn-sm " style="font-size: 9px; " ><span class=" fa fa-download " > Unduh</span></a>
          <?php else: ?>
          Tidak Ada bukti
          <?php endif; ?>

      </td>

       <?php
 
            $tindakan_id = $lk->id_tindakan;
             
            $catatan = catatan::where('id_tindakan','=',$tindakan_id)->get();
            
             $catatann = $catatan;  
              // dd($catatann); 
          ?>

      <td  style=" width: 120px;">

          <b>Catatan: </b><br>
                      <?php $no = 0;?>
                    <?php $__currentLoopData = $catatann; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <?php $no++ ;?>

                     <?php echo e($cat ->catatan_tindakan); ?>  <br> <b style=" font-size: 10px; " > <?php echo e(\Carbon\Carbon::parse ($cat ->updated_at)->format('d/m/Y')); ?> </b><br><br>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <br>
                

              <?php if($lk->status_tindakan =='Terkirim'): ?>
               
               <div style=" text-align: center; " > <a href="<?php echo e(route('tindakan', $lk->id)); ?>"><button  style="font-size: 9px; " class="btn btn-info btn-sm" ><span class=" fa fa-pencil " >  Tambah Catatan</span></button></a> </div> 
              

              <?php else: ?>
             <?php endif; ?>
      </td>
      

      <td style=" width: 80px;text-align:center;">
        
          <?php if($lk->catatan_verifikasi == !NULL): ?>
                 <?php if($lk->status_tindakan =='dikembalikan'): ?>

                   <i class="fa fa-undo" style="  font-size: 1.2em; width: 1.7em; text-align: center;line-height: 0.8em;background: #c9ba01;color: #fff;border-radius: 0.8em; " >   </i><br>
                   <?php echo e($lk->status_tindakan); ?><br>

                <?php elseif($lk->catatan_verifikasi == !NULL  & $lk->status_tindakan =='Terkirim'): ?>
                  <form class="form-horizontal" action="<?php echo e(route('kembalikantindakan',$lk->id_tindakan)); ?>" method="post">
                 <?php echo e(csrf_field()); ?>

                   <input type="hidden" class="form-control" id="status_tindakan" name="status_tindakan" value="dikembalikan">   
                   <button type="submit" style="width: 75px; font-size: 10px; background-color:  #c9ba01; color: white; "  class="btn btn-sm " onclick="return confirm('Kembalikan Tindakan Ini Ke Auditee? ')" ><span class=" fa fa-undo " >  Kembalikan</span></button> 
                   <input type="hidden" name="_method" value="PUT">
                 </form>
                 <br>
                <?php endif; ?>
         <?php endif; ?>

<?php $nama=$auditor->nama; ?>

         <?php if($lk->status_tindakan =='Terkirim'): ?>
                    <form class="form-horizontal" action="<?php echo e(route('verifikasitindakan',$lk->id_tindakan)); ?>" method="post">
                 <?php echo e(csrf_field()); ?>

                   <input type="hidden" class="form-control" id="status_tindakan" name="status_tindakan" value="Ter-Verifikasi"> 
                    <input type="hidden" class="form-control" id="nama" name="nama" value="<?php echo e($nama); ?>">

                   <button type="submit" style="width: 75px; font-size: 10px;  color: white; "  class="btn btn-sm btn-success " onclick="return confirm('Anda Yakin Untuk Mem-Verifikasi Tindakan Ini?')" ><span class=" fa fa-check " >  Verifikasi</span></button>
                   <input type="hidden" name="_method" value="PUT">
                 </form>
                 <?php elseif($lk->status_tindakan =='Ter-Verifikasi'): ?>
                   <p class="fa fa-check" style="font-size: 1.2em; width: 1.7em; text-align: center; line-height: 0.8em;background: blue; color: #fff; border-radius: 0.8em;" > </p><br>
                   <?php echo e($lk->status_tindakan); ?><br><br>
                   <a href="<?php echo e(route('lihat',$lk->id_tindakan)); ?>" class="btn btn-primary btn-sm" style="font-size: 10px;"><span class=" fa fa-print " >  Cetak LKS</span></a>
        <?php endif; ?>
      </td>
    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </table>
  </div>
</div>

</body>
<br><br><br><br><br><br><br>

 

<script>
    var msg = '<?php echo e(Session::get('alert')); ?>';
    var exist = '<?php echo e(Session::has('alert')); ?>';
    if(exist){
      alert(msg);
    }
  </script>
  <?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</html>
