<!DOCTYPE html>
<html>
<head>

	<?php echo $__env->make('layout.head-css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->make('auditee.headerauditee', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<title>Daftar LKS Yang Akan Ditindak</title>
</head>
<body>

<div class="container" style="font-size: 12px;"><br> <br>

  <h5 style="text-align: left; " >Area Audit :  <br>

    <?php if(Auth::user()->lokasi==NULL): ?>
    <i style=" color: red; " >  Akun Anda Tidak Aktif, Silahkan Hubungi Admin !</i>
    <?php else: ?>
    <?php echo e(Auth::user()->lokasi); ?>

    <?php endif; ?>

  </h5>
    <h5 style="text-align: center " >DAFTAR LAPORAN KETIDAKSESUAIAN</h5><br>

<div class="table-responsive">
		<table class="table  table-striped table-bordered w-auto "  >

    	<tr>

      	<th style="text-align:center;">No LKS</th>
        <th style="text-align:center;">Tanggal Terbit</th>
        <th style="text-align:center;">Dokumen Acuan</th>
      	<th style="text-align:center;">Deskripsi Ketidaksesuaian</th>
      	<th style="text-align:center; width: 240px; ">Tidak Sesuai Dengan</th>
        <th style="text-align:center;">Aksi</th>
    
    	</tr>

<?php $__currentLoopData = $lks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>  

        <td style="text-align:center; width: 55px; "> <?php echo e($lk -> nolks); ?> </td>
        <td style="text-align:center; width: 90px; ">  <?php echo e(\Carbon\Carbon::parse ($lk->tgl_terkirim)->format('d-m-Y')); ?></td>
        <td style="text-align:left;"> <?php echo e($lk -> acuan); ?> </td>
        <td style="text-align:left; width: 380px; "> <?php echo e($lk -> deskripsi); ?> </td>
        <td style="text-align:left;"><b>SNI ISO/IEC 17065:2012 Klausul :</b><br> <?php echo e($lk -> iec_2012); ?> <br>
                                       <b>ISO/IEC 17021-1:2015 Klausul :</b><br> <?php echo e($lk -> iec_2015); ?> <br>
                                       <b>ISO/IEC 17021-3:2017 Klausul :</b><br> <?php echo e($lk -> iec_2017); ?> <br>
                                       <b>Dokumen SMM :</b><br> <?php echo e($lk -> smm); ?> </td>
        <td style="text-align:center; width: 110px; " >
           <?php if( $lk->status=="Terkirim"): ?>
           <a href="<?php echo e(route('buattindakan',$lk->id)); ?>"><button class="btn btn-primary btn-sm" style=" font-size: 11px; "><span class=" fa fa-pencil " >  Tindakan</span></button></a>
       
         <?php else: ?>
        <p class=" fa fa-check " style="font-size: 1.2em; width: 1.7em; text-align: center; line-height: 0.8em;background: green; color: #fff; border-radius: 0.8em;" >  </p> <br> <span> <?php echo e($lk->status); ?> </span>
         <?php endif; ?>
        	
        </td>

    </tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
  </table>
  </div>

</div>

</body>
</html>
<?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>