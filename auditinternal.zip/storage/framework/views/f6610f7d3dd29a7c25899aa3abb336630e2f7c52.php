

<!DOCTYPE html>
<html>
<head>

 <?php echo $__env->make('layout.head-css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <?php echo $__env->make('auditor.headerauditor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@300;400&display=swap" rel="stylesheet">
 <style>
 
  </style>

	<title>Daftar Laporan Ketidakseuaian</title>
</head>
<body>



	
<div class=" container-fluid" style=" font-size: 12px ; " > 

		

<div class="breadcrumb" style="margin-bottom: 5px;" >
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-6">
         <div  style="font-size: 20px; color: #3993d0; font-weight: bold; "> <span class="fa fa-folder-open" > </span> Daftar Laporan Ketidaksesuaian</div>
   </div>
     
      <div class="col-md-6"style=" text-align: right !important; " >
        <i style="font-size: 15px; color: #3993d0; font-weight: bold;" > Jumlah LKS :  <?php echo e($totaldata); ?> &nbsp; &nbsp;( Terkirim : <?php echo e($terkirimm); ?>, Belum Terkirim : <?php echo e($belumterkirim); ?> )&nbsp;&nbsp;</i>
      </div>
       </div>
    </div>
    
  </div> 










    <div class="table-responsive">
		<table class="table table-striped table-bordered"  >

    	<tr>

      	<th class="  text-center "  data-toggle="tooltip" data-placement="top" title="Nomor LKS akan terisi setelah terkirim ke auditee"><u> NO LKS</u></th>
        <th class="  text-center ">PENULIS</th>
        <th class="  text-center ">DOKUMEN ACUAN</th>
      	<th class="  text-center ">DESKRIPSI KETIDAKSESUAIAN</th>
      
        <th class="  text-center ">TIDAK SESUAI DENGAN</th>
        <th class="  text-center ">STATUS</th>
         <th class="  text-center ">AKSI</th>
    
    	</tr>


      <?php $no = 0;?>

    <?php $__currentLoopData = $lks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php $no++ ;?> 

    <tr>  
      <td class="  text-center " style="min-width: 70px;" ><b><?php echo e($lk ->nolks); ?></b> </td>
      <td > <?php echo e($lk ->nama_penulis); ?> </td>
      <td style="white-space: pre-line;"> <?php echo e($lk ->acuan); ?> </td>
      <td  style="white-space: pre-line; width: 410px;"> <?php echo e($lk ->deskripsi); ?> </td>
    
      <td style="max-width: 320px; min-width: 300px;" > <b>SNI ISO/IEC 17065:2012 Klausul: </b><br><?php echo e($lk ->iec_2012); ?> <br><br><b>ISO/IEC 17021-1:2015 Klausul:<br> </b> <?php echo e($lk ->iec_2015); ?> <br><br><b> ISO/IEC 17021-3:2017 Klausul: </b><br>  <?php echo e($lk ->iec_2017); ?> <br><br><b>(Dokumen SMM): </b><br><?php echo e($lk ->smm); ?></td>



      <td style=" text-align: center; min-width: 120px;" >
          <?php if( $lk->status==NULL): ?>
  
          <?php else: ?>
          <i class="fa fa-check"  style="  font-size: 1.2em;width: 1.7em;text-align: center;line-height: 0.8em; height: 1.1em; padding-top: 2px; padding-bottom: 2px; background: green;color: #fff;border-radius: 0.8em; " >  </i><br>
          <?php echo e($lk->status); ?><br>
    
          <?php endif; ?>

          <?php if($lk->status=="Terkirim"): ?>
             <i style="font-size: 10px;" > <?php echo e(\Carbon\Carbon::parse ($lk ->tgl_terkirim)->format('d/m/Y')); ?></i>
             <?php else: ?>
             <?php echo e(""); ?>

          <?php endif; ?> 
      </td>

    


    <td style="text-align:center; min-width: 60px; padding-left: 3px; padding-right: 3px; " >


        <?php
        $lkid= \Crypt::encrypt($lk->id) ;
        ?>

         <?php if( $lk->status==NULL): ?>
          <a href="<?php echo e(route('editlks',$lkid)); ?>" style=" margin-bottom: 2px; "  data-toggle="tooltip" data-placement="top" title="Edit LKS"><button class="btn btn-primary "  >   <span  style="font-size: 13px " class=" fa fa-edit " ></span></button></a>
       
<?php    $nama= $auditor->nama; ?>
     
        <form class="form-horizontal" action="<?php echo e(route('kirimlks',$lk->id)); ?>" method="post" style="margin-top: 2px;">
          <?php echo e(csrf_field()); ?>      
              <input type="hidden" class="form-control" id="status" name="status" value="Terkirim">
              <input type="hidden" class="form-control" id="nama" name="nama" value="<?php echo e($nama); ?>"> 
               <input type="hidden" class="form-control" id="nlks" name="nolks" value="<?php echo e($no); ?>">          
              <button type="submit" style=""  class="btn  btn-success" data-toggle="tooltip" data-placement="top" title="Kirim LKS" onclick="return confirm('Setelah Terkirim, Anda tidak akan bisa mengubahnya lagi. yakin untuk mengirim LKS ini Ke Auditee ? ')" ><span  style="font-size: 13px " class=" fa fa-send " > </button>

              <input type="hidden" name="_method" value="PUT">
          </form>


 
           <?php else: ?>
          
          <?php endif; ?>
      </td>
    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
  </table>
  </div>
 <br><br> <i style="font-size: 14px;" >*Nomor LKS akan terisi setelah terkirim ke auditee, dan ditentukan berdasarkan urutan pengiriman</i> 
</div>

</body><br><br><br><br><br>


<script>
    var msg = '<?php echo e(Session::get('alert')); ?>';
    var exist = '<?php echo e(Session::has('alert')); ?>';
    if(exist){
      alert(msg);
    }
  </script>
  
</html>
 <?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>