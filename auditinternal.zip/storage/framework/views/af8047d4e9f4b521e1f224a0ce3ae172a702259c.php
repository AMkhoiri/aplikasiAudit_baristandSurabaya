<!DOCTYPE html>
<html>
<head>
	<?php echo $__env->make('layout.head-css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->make('kepala.headerkepalabalai', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<title> Kepala Balai - Pilih Auditee</title>
	<style>
		.area{
			width: 320px;
		}

		.auditee{
			width: 480px;
		}
	</style>
</head>
<body>



<div class="container-fluid"  style="font-size: 12px; "> 



<div class="breadcrumb" style="margin-bottom: 5px; margin-top: 6px;" >
  <div class="container-fluid">
   <div class="row">
     <div class="col-md-6" style="font-size: 20px; color: #3993d0; font-weight: bold; "> <span class="fa fa-folder-open" > </span> Pilih Auditee</div>
      <div class="col-md-6" style=" " >   
      	 <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger  " style=" align-content: center; margin-bottom: 0px; font-weight: bold;" >
              
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
            <?php endif; ?>

      </div>
            
    </div>
   </div>
  </div> 





	
		<table class="table table-striped table-bordered  "  >
			<tr>
				<th class="area" >Area Audit</th>
				<th class="auditee">Auditee</th>
				<th>Pilih auditee</th>
			</tr>

			<tr>
				<td>Top Manajemen</td>
				<td>
						 <?php $no = 0;?> 
					<?php $__currentLoopData = $auditee1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php $no++ ;?>  
					<div class="row">
						<div class="col-md-1"> <?php echo e($no); ?> </div>
						<div class="col-md-9"><?php echo e($a->nama); ?></div>
						<div class="col-md-2">
							<form action=" ../kepala/auditee/<?php echo e($a->id); ?>"  method="post" >     
				         	 <button  class="btn btn-danger btn-sm " style="margin-bottom: 3px;"  onclick="return confirm('Anda Yakin menghapus <?php echo e($a->nama); ?> dari auditee ?')" type="submit" name="submit" data-toggle="tooltip" data-placement="top" title="Hapus" ><span class="fa fa-close" ></span> </button>
					          <?php echo e(csrf_field()); ?>

					          <input type="hidden" name="_method" value="DELETE" >
		      				</form>
						</div>
					</div>
			      	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</td>
				
				<td>
					 <form action="<?php echo e(url('kepala/auditee/create')); ?>" method="post"> 
			        	 <?php echo e(csrf_field()); ?>

			 				<div class="row">
			 					<div class="col-md-10">
			 						<select class="custom-select " id="Sie" name="nama" required>
								        <option value="" >Pilih auditee</option>
									  	<?php $__currentLoopData = $pegawai1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									        <option value="<?php echo e($p->nama); ?>"><?php echo e($p->nama); ?> </option>
									         <?php $id= $p->id; ?>
									    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					     			</select>
		     			 			<input type="hidden" name="lokasi_audit" class="form-control" value="Top Manajemen"  required/><br>
			 					</div>
			 					<div class="col-md-2">
			 						<button  type="submit" class="btn btn-sm btn-primary " data-toggle="tooltip" data-placement="top" title="Simpan" ><span class="fa fa-save" ></span></button>    
			 					</div>
			 				</div>	       
			 		</form>
				</td>
				
			</tr>
		</table>


		<table class="table table-striped table-bordered  "  >
			<tr>
				<th class="area">Area Audit</th>
				<th class="auditee">Auditee</th>
				<th>Pilih auditee</th>
			</tr>

			<tr>
				<td>Sub Bag Tata Usaha</td>
				<td>
						 <?php $no = 0;?> 
					<?php $__currentLoopData = $auditee2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php $no++ ;?>  
					<div class="row">
						<div class="col-md-1"> <?php echo e($no); ?> </div>
						<div class="col-md-9"><?php echo e($a->nama); ?></div>
						<div class="col-md-2">
							<form action=" ../kepala/auditee/<?php echo e($a->id); ?>"  method="post" >     
				         	 <button  class="btn btn-danger btn-sm " style="margin-bottom: 3px;"  onclick="return confirm('Anda Yakin menghapus <?php echo e($a->nama); ?> dari auditee ?')" type="submit" name="submit" data-toggle="tooltip" data-placement="top" title="Hapus" ><span class="fa fa-close" ></span> </button>
					          <?php echo e(csrf_field()); ?>

					          <input type="hidden" name="_method" value="DELETE" >
		      				</form>
						</div>
					</div>
			      	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</td>
				
				<td>
					 <form action="<?php echo e(url('kepala/auditee/create')); ?>" method="post"> 
			        	 <?php echo e(csrf_field()); ?>

			 				<div class="row">
			 					<div class="col-md-10">
			 						<select class="custom-select " id="Sie" name="nama" required>
								        <option value="" >Pilih auditee</option>
									  	<?php $__currentLoopData = $pegawai2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									        <option value="<?php echo e($p->nama); ?>"><?php echo e($p->nama); ?> </option>
									         <?php $id= $p->id; ?>
									    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					     			</select>
		     			 			<input type="hidden" name="lokasi_audit" class="form-control" value="Sub Bag Tata Usaha"  required/><br>
			 					</div>
			 					<div class="col-md-2">
			 						<button  type="submit" class="btn btn-sm btn-primary " data-toggle="tooltip" data-placement="top" title="Simpan" ><span class="fa fa-save" ></span></button>    
			 					</div>
			 				</div>	       
			 		</form>
				</td>
				
			</tr>
		</table>


				<table class="table table-striped table-bordered  "  >
			<tr>
				<th class="area">Area Audit</th>
				<th class="auditee" >Auditee</th>
				<th>Pilih auditee</th>
			</tr>

			<tr>
				<td>Seksi Pengembangan jasa Teknis</td>
				<td>
						 <?php $no = 0;?> 
					<?php $__currentLoopData = $auditee3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php $no++ ;?>  
					<div class="row">
						<div class="col-md-1"> <?php echo e($no); ?> </div>
						<div class="col-md-9"><?php echo e($a->nama); ?></div>
						<div class="col-md-2">
							<form action=" ../kepala/auditee/<?php echo e($a->id); ?>"  method="post" >     
				         	 <button  class="btn btn-danger btn-sm " style="margin-bottom: 3px;"  onclick="return confirm('Anda Yakin menghapus <?php echo e($a->nama); ?> dari auditee ?')" type="submit" name="submit" data-toggle="tooltip" data-placement="top" title="Hapus" ><span class="fa fa-close" ></span> </button>
					          <?php echo e(csrf_field()); ?>

					          <input type="hidden" name="_method" value="DELETE" >
		      				</form>
						</div>
					</div>
			      	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</td>
				
				<td>
					 <form action="<?php echo e(url('kepala/auditee/create')); ?>" method="post"> 
			        	 <?php echo e(csrf_field()); ?>

			 				<div class="row">
			 					<div class="col-md-10">
			 						<select class="custom-select " id="Sie" name="nama" required>
								        <option value="" >Pilih auditee</option>
									  	<?php $__currentLoopData = $pegawai3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									        <option value="<?php echo e($p->nama); ?>"><?php echo e($p->nama); ?> </option>
									         <?php $id= $p->id; ?>
									    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					     			</select>
		     			 			<input type="hidden" name="lokasi_audit" class="form-control" value="Seksi Pengembangan jasa Teknis"  required/><br>
			 					</div>
			 					<div class="col-md-2">
			 						<button  type="submit" class="btn btn-sm btn-primary " data-toggle="tooltip" data-placement="top" title="Simpan" ><span class="fa fa-save" ></span></button>    
			 					</div>
			 				</div>	       
			 		</form>
				</td>
				
			</tr>
		</table>




				<table class="table table-striped table-bordered  "  >
			<tr>
				<th class="area">Area Audit</th>
				<th class="auditee">Auditee</th>
				<th>Pilih auditee</th>
			</tr>

			<tr>
				<td>Seksi Standarisasi Dan Sertifikasi / Operasional</td>
				<td>
						 <?php $no = 0;?> 
					<?php $__currentLoopData = $auditee4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php $no++ ;?>  
					<div class="row">
						<div class="col-md-1"> <?php echo e($no); ?> </div>
						<div class="col-md-9"><?php echo e($a->nama); ?></div>
						<div class="col-md-2">
							<form action=" ../kepala/auditee/<?php echo e($a->id); ?>"  method="post" >     
				         	 <button  class="btn btn-danger btn-sm " style="margin-bottom: 3px;"  onclick="return confirm('Anda Yakin menghapus <?php echo e($a->nama); ?> dari auditee ?')" type="submit" name="submit" data-toggle="tooltip" data-placement="top" title="Hapus" ><span class="fa fa-close" ></span> </button>
					          <?php echo e(csrf_field()); ?>

					          <input type="hidden" name="_method" value="DELETE" >
		      				</form>
						</div>
					</div>
			      	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</td>
				
				<td>
					 <form action="<?php echo e(url('kepala/auditee/create')); ?>" method="post"> 
			        	 <?php echo e(csrf_field()); ?>

			 				<div class="row">
			 					<div class="col-md-10">
			 						<select class="custom-select " id="Sie" name="nama" required>
								        <option value="" >Pilih auditee</option>
									  	<?php $__currentLoopData = $pegawai4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									        <option value="<?php echo e($p->nama); ?>"><?php echo e($p->nama); ?> </option>
									         <?php $id= $p->id; ?>
									    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					     			</select>
		     			 			<input type="hidden" name="lokasi_audit" class="form-control" value="Seksi Standarisasi Dan Sertifikasi / Operasional"  required/><br>
			 					</div>
			 					<div class="col-md-2">
			 						<button  type="submit" class="btn btn-sm btn-primary " data-toggle="tooltip" data-placement="top" title="Simpan" ><span class="fa fa-save" ></span></button>    
			 					</div>
			 				</div>	       
			 		</form>
				</td>
				
			</tr>
		</table>




				<table class="table table-striped table-bordered  "  >
			<tr>
				<th class="area">Area Audit</th>
				<th class="auditee">Auditee</th>
				<th>Pilih auditee</th>
			</tr>

			<tr>
				<td>Seksi Standarisasi Dan Sertifikasi / Mutu</td>
				<td>
						 <?php $no = 0;?> 
					<?php $__currentLoopData = $auditee5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php $no++ ;?>  
					<div class="row">
						<div class="col-md-1"> <?php echo e($no); ?> </div>
						<div class="col-md-9"><?php echo e($a->nama); ?></div>
						<div class="col-md-2">
							<form action=" ../kepala/auditee/<?php echo e($a->id); ?>"  method="post" >     
				         	 <button  class="btn btn-danger btn-sm " style="margin-bottom: 3px;"  onclick="return confirm('Anda Yakin menghapus <?php echo e($a->nama); ?> dari auditee ?')" type="submit" name="submit" data-toggle="tooltip" data-placement="top" title="Hapus" ><span class="fa fa-close" ></span> </button>
					          <?php echo e(csrf_field()); ?>

					          <input type="hidden" name="_method" value="DELETE" >
		      				</form>
						</div>
					</div>
			      	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</td>
				
				<td>
					 <form action="<?php echo e(url('kepala/auditee/create')); ?>" method="post"> 
			        	 <?php echo e(csrf_field()); ?>

			 				<div class="row">
			 					<div class="col-md-10">
			 						<select class="custom-select " id="Sie" name="nama" required>
								        <option value="" >Pilih auditee</option>
									  	<?php $__currentLoopData = $pegawai5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									        <option value="<?php echo e($p->nama); ?>"><?php echo e($p->nama); ?> </option>
									         <?php $id= $p->id; ?>
									    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					     			</select>
		     			 			<input type="hidden" name="lokasi_audit" class="form-control" value="Seksi Standarisasi Dan Sertifikasi / Mutu"  required/><br>
			 					</div>
			 					<div class="col-md-2">
			 						<button  type="submit" class="btn btn-sm btn-primary " data-toggle="tooltip" data-placement="top" title="Simpan" ><span class="fa fa-save" ></span></button>    
			 					</div>
			 				</div>	       
			 		</form>
				</td>
				
			</tr>
		</table>













































</body>
</html>
<?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>