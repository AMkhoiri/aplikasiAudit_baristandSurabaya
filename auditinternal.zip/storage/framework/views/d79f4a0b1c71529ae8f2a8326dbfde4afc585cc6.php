
<?php 

use App\catatan;

 ?>

<!DOCTYPE html>
<html>
<head>


 <?php echo $__env->make('layout.head-css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <?php echo $__env->make('auditor.headerauditor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <title>Tindakan Perbaikan</title>
</head>

<body>

<div class=" container-fluid" style=" font-size: 12px ; " > 
 


<div class="breadcrumb" style="margin-bottom: 5px;" >
  <div class="container-fluid">
     <div  style="font-size: 20px; color: #3993d0; font-weight: bold; "> <span class="fa fa-folder-open" > </span> Daftar Tindakan Perbaikan</div>
   </div>
  </div> 



<div class="table-responsive">
    <table class="table  table-striped table-bordered"  >

      <tr>

        <th style="text-align:center;">NO LKS</th>
        <th style="text-align:center;">DOKUMEN ACUAN|DESKRIPSI KETIDAKSESUAIAN</th>
        <th style="text-align:center;">TIDAK SESUAI DENGAN</th>
        <th style="text-align:center;">TINDAKAN</th>
         <th style="text-align:center;">FILE BUKTI</th>
         <th style="text-align:center;">CATATAN</th>
         <th style="text-align:center;">STATUS</th>
         <th style="text-align:center;">AKSI</th>

      </tr>

    
    <?php $__currentLoopData = $tindakanlks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

    <tr>  
      <td style="text-align:center; "> <?php echo e($lk ->nolks); ?> </td>
      <td style="; text-align:left; white-space: pre-line; max-width: 330px;">   <b> Dokumen Acuan: </b> <br><?php echo e($lk ->acuan); ?><br><br><b> Deskripsi Ketidaksesuaian: </b> <br><?php echo e($lk ->deskripsi); ?>

      </td>
      <td style=" max-width: 320px; "><b>SNI ISO/IEC 17065:2012 Klausul :</b><br> <?php echo e($lk ->iec_2012); ?> <br><br>
                                   <b>ISO/IEC 17021-1:2015 Klausul :</b><br> <?php echo e($lk ->iec_2015); ?> <br><br>
                                   <b>ISO/IEC 17021-3:2017 Klausul :</b><br> <?php echo e($lk ->iec_2017); ?> <br><br>
                                   <b>Dokumen SMM :</b><br> <?php echo e($lk ->smm); ?> </td>


      <td  style=" white-space: pre-line; min-width: 250px; max-width: 320px; "> <b> Akar Permasalahan : </b><br><?php echo e($lk ->akar); ?><br>
          <b> Tindakan Dilakukan : </b><br><?php echo e($lk ->dilakukan); ?><br>
           <b> Tindakan Pencegahan : </b><br><?php echo e($lk ->pencegahan); ?><br>
      </td>
       <td class="  text-center " style="width: 90px; "  >  <?php if($lk->title == !NULL): ?>  <img style="width: 20px;" src="<?php echo e(asset('audit/img/document.png')); ?>" alt=""> <br>  <?php echo e($lk ->title); ?>

        <?php else: ?> 
        <?php endif; ?>  <br><br> 



      </td>

<?php
  $tindakan_id = $lk->id_tindakan; 
    $catatan = catatan::where('id_tindakan','=',$tindakan_id)->get();
     $catatann = $catatan;  

?>


      <td  style=" min-width: 150px; max-width: 270px; ">

          <b>Catatan: </b><br>
              <?php $no = 0;?>
            <?php $__currentLoopData = $catatann; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <?php $no++ ;?>

             <?php echo e($cat ->catatan_tindakan); ?>  <br> <b style=" font-size: 9px; " > <?php echo e(\Carbon\Carbon::parse ($cat ->updated_at)->format('d/m/Y')); ?> </b>
             <?php if($cat->status=="new"): ?>
               <span style="font-size: 11px; color: #00cc00;" class="fa fa-arrow-circle-up" > </span>
             <?php elseif($cat->status=="Terkirim"): ?>
             <span style="font-size: 11px; color: #00cc00;" class="fa fa-send" > </span>
              <?php elseif($cat->status=="selesai"): ?>
             <span style="font-size: 11px; color: #00cc00;" class="fa fa-check" > </span>
             <?php else: ?>
             <?php endif; ?>
             <br><br>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <br>  
      </td>

     
      <td style="text-align:center; min-width: 90px; padding-right: 2px; padding-left: 2px; " >
            <?php if($lk->status_tindakan =='dikembalikan'): ?>
                 <i class="fa fa-undo" style="  font-size: 1.2em; width: 1.7em; height: 1.1em; padding-top: 2px; padding-bottom: 2px; text-align: center;line-height: 0.8em;background: #c9ba01;color: #fff;border-radius: 0.8em; " >   </i><br>
                 <?php echo e($lk->status_tindakan); ?>


            <?php elseif($lk->status_tindakan =='Ter-Verifikasi'): ?>
             <i class="fa fa-check" style="font-size: 1.2em; width: 1.7em; height: 1.1em; padding-top: 2px; padding-bottom: 2px; text-align: center; line-height: 0.8em;background: blue; color: #fff; border-radius: 0.8em;" > </i><br>
                   <?php echo e($lk->status_tindakan); ?>


            <?php else: ?>   
             
                   
                   
            <?php endif; ?>        

      </td>




      <td style=" min-width: 60px; text-align:center; padding-left: 2px;padding-right: 2px; ">

          <?php if($lk->title == !NULL): ?>
          <a href="<?php echo e(route ('downloadfile', $lk->id_tindakan)); ?>" data-toggle="tooltip" data-placement="top" title="Unduh file bukti" class=" btn btn-info  " style="font-size: 12px; margin-bottom: 2px;" ><span class=" fa fa-download " ></span></a><br>
          <?php else: ?>
          
          <?php endif; ?>

            <?php $nama=$auditor->nama; ?>

         <?php if($lk->status_tindakan =='Terkirim'): ?> 

                               <?php 
                              $lkid= \Crypt::encrypt($lk->id) ; 
                              ?> 
              <a href="<?php echo e(route('tindakan', $lkid)); ?>" data-toggle="tooltip" data-placement="top" title="Tulis catatan"><button  style="font-size: 14px;text-align: center;margin-bottom: 2px; " class="btn btn-info " ><span class=" fa fa-pencil " ></span></button></a> 


                <?php
                 //mengecek apakah ada catatan yang bisa dikirim ke auditee (berstatus NULL)
                 $catt = catatan::where('id_tindakan','=',$tindakan_id) ->where('status', "new")->first();

                 // dd($catt);
                ?>

                    <?php if($catt): ?>

                        <form class="form-horizontal" action="<?php echo e(route('kembalikantindakan',$lk->id_tindakan)); ?>" method="post" style="margin-bottom: 2px;">
                       <?php echo e(csrf_field()); ?>

                         <input type="hidden" class="form-control" id="status_tindakan" name="status_tindakan" value="dikembalikan">   
                         <button type="submit" style=" font-size: 14px;  color: white; "data-toggle="tooltip" data-placement="top" title="Kembalikan ke auditee"  class="btn btn-warning  " onclick="return confirm('Kembalikan Tindakan Ini Ke Auditee? ')" ><span class=" fa fa-undo " ></span></button> 
                         <input type="hidden" name="_method" value="PUT">
                       </form>
                       <?php else: ?>

                    <?php endif; ?>

                      
                 
               

              <form class="form-horizontal" action="<?php echo e(route('verifikasitindakan',$lk->id_tindakan)); ?>" method="post" style="margin-bottom: 2px;" >
               <?php echo e(csrf_field()); ?>

                 <input type="hidden" class="form-control" id="status_tindakan" name="status_tindakan" value="Ter-Verifikasi"> 
                  <input type="hidden" class="form-control" id="nama" name="nama" value="<?php echo e($nama); ?>">

                 <button type="submit" style=" font-size: 13px; color: white; "  class="btn b btn-success " onclick="return confirm('Anda Yakin Untuk Verifikasi Tindakan Ini?')" data-toggle="tooltip" data-placement="top" title="Verifikasi tindakan perbaikan" ><span class=" fa fa-check " ></span></button>
                 <input type="hidden" name="_method" value="PUT">
           </form>

          <?php elseif($lk->status_tindakan =='Ter-Verifikasi'): ?>

                  <?php
                  $lkid= \Crypt::encrypt($lk->id_tindakan) ;
                  ?>
                 
                   <a href="<?php echo e(route('lihat',$lkid)); ?>" target="_blank" >  <button class="btn btn-primary " style="font-size: 13px; " data-toggle="tooltip" data-placement="top" title="cetak LKS" > <span class=" fa fa-print " ></span></button></a>
        <?php endif; ?>
      </td>
    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </table>
  </div>

   <br><br> <i style="font-size: 14px;" >*Ketika tindakan dikembalikan, catatan yang terlihat oleh auditee hanya catatan yang terakhir ditulis</i> 
</div>

</body>
<br><br><br><br><br><br><br>

 

<script>
    var msg = '<?php echo e(Session::get('alert')); ?>';
    var exist = '<?php echo e(Session::has('alert')); ?>';
    if(exist){
      alert(msg);
    }
  </script>
  <?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</html>
