<!DOCTYPE html>
<html>
<head>

	<?php echo $__env->make('layout.head-css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->make('admin.headeradmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


	<title>Edit Data Pegawai</title>
</head>
<body>

		<br><br><br><br><br>
		<div class="container">
		  <h3>Edit Data Pegawai</h3><br>
		  <form class="form-horizontal" action="<?php echo e(route('updatepegawai',$pegawai->id)); ?>" method="post" >
		  	<?php echo e(csrf_field()); ?>

		   
		  	 <div class="form-group row ">
		      <label class="control-label col-sm-2" for="nama">Nama Pegawai : </label>
		      <div class="col-sm-6">          
		        <input type="text" class="form-control" id="nama" value=" <?php echo e($pegawai->nama); ?> " name="nama">
		      </div>
		    </div>

		   <!--  <div class="form-group row">
		      <label class=" control-label col-sm-2" for="jk" >Jenis Kelamin : </label>
		      <div class=" col-sm-8 " >
		      	<select class="custom-select " id="jk" name="jk" required>
			        <option value="">Pilih...</option>
			        <option value="Laki Laki">laki - Laki</option>
			        <option value="Perempuan">Perempuan</option>
			        
		     	</select>
		      </div>
		    </div> -->

		     <div class="form-group row">
		      <label class="control-label col-sm-2" for="nip" >NIP :</label>
		      <div class="col-sm-3">          
		        <input type="text" class="form-control" id="nip"  name="nip" value=" <?php echo e($pegawai->nip); ?> ">
		      </div>
		    </div>

		    

		   <div class="form-group row">
		      <label class=" control-label col-sm-2" for="Sie">Sie :</label>
		      <div class=" col-sm-6 " >
		      	<select class="custom-select " id="Sie" name="sie" required>
			        <option value="" >Pilih Sie...</option>
			        <option value="Top Manajemen">Top Manajemen</option>
			        <option value="Sub Bag Tata Usaha">Sub Bag Tata Usaha</option>
			        <option value="Seksi Pengembangan jasa Teknis">Seksi Pengembangan jasa Teknis</option>
			        <option value="Seksi Standarisasi Dan Sertifikasi / Operasional">Seksi Standarisasi Dan Sertifikasi</option>
			        
			         <option value="Seksi Program Dan Pengembangan Kompetensi">Seksi Program Dan Pengembangan Kompetensi</option>
			          <option value="Seksi Teknologi Industri">Seksi Teknologi Industri</option>
		     	</select>
		      </div>
		    </div>


		    <div class="form-group row">
		      <label class="control-label col-sm-2" for="jabatan">Jabatan :</label>
		      <div class="col-sm-6">          
		        <input type="text" class="form-control" id="jabatan" placeholder="Masukkan Jabatan" name="jabatan">
		      </div>
		    </div>


		    <div class="form-group row">  
		    	<label class="control-label col-sm-2" for="submit"></label>      
		      <div class="col-sm-offset-2 col-sm-6">
		      	<a  class="btn btn-sm btn-secondary " href="<?php echo e(url ('admin/datapegawai')); ?> " style=" width: 75px; " ><span class=" fa fa-arrow-left " >  Batal</span></a>
		         <button  type="submit" class="btn btn-primary btn-sm "style=" width: 75px; "  ><span class=" fa fa-save " >  Simpan</span></button>

                    

                        <input type="hidden" name="_method" value="PUT">
		      </div>
		    </div>
		  </form>
		</div>

<br><br><br>
</body>
</html>
<?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>