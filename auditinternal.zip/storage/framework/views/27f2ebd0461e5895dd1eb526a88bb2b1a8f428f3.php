<!DOCTYPE html>
<html>
<head>

 <?php echo $__env->make('layout.head-css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <?php echo $__env->make('auditor.headerauditor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<title>Form Verifikasi</title>

</head>
<body>

<div class="container" style="margin-top: 20px; font-size: 12px;"><br>

    <h5>Laporan Ketidaksesuaian :</h5>

	<table class="table table-responsive table-striped table-bordered"  >

	
	    <tr>
	      <th style="text-align:center;">No LKS</th>
	      <th style="text-align:center;">Deskripsi Ketidaksesuaian</th>
	      <th style="text-align:center;">Dokumen Acuan</th>
	      <th style="text-align:center;">Tidak Sesuai Dengan SNI ISO/IEC 17065:2012 Klausul</th>
	      <th style="text-align:center;">Tidak Sesuai Dengan SNI ISO/IEC 17021-1:2015 Klausul</th>
	      <th style="text-align:center;">Tidak Sesuai Dengan SNI ISO/IEC 17021-1:2017 Klausul</th>
	      <th style="text-align:center;">Tidak Sesuai Dengan (Dokumen SMM)</th>
	    </tr>

	<?php $no = 0;?>
    <?php $no++ ;?>

	    <tr>  
	      <td style="text-align:center; width: 45px; "> <?php echo e($no); ?> </td>
	      <td style="width: 280px;">  <?php echo e($lks->deskripsi); ?></td>
	      <td style="width: 100px;"> <?php echo e($lks->acuan); ?> </td>
	      <td style="text-align:center;"> <?php echo e($lks->iec_2012); ?> </td>
	      <td style="text-align:center;">  <?php echo e($lks->iec_2015); ?> </td>
	      <td style="text-align:center;">   <?php echo e($lks->iec_2017); ?></td>
	      <td style="text-align:center;">   <?php echo e($lks->smm); ?></td>
   		</tr>
	
   	<?php  $id_lks= $lks->id ?>

	</table><br>


	<h5>Tindakan Perbaikan :</h5>

	<table class="table table-striped table-bordered">
		<tr>
			<th style="text-align:center;">Akar Permasalahan</th>
	        <th style="text-align:center;">Tindakan Yang Dilakukan</th>
	        <th style="text-align:center;">Tindakan Pencegahan</th>
	      	<th style="text-align:center;">Bukti</th>
		</tr>

<?php $__currentLoopData = $tindakan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tdk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
	      <td style=""> <?php echo e($tdk -> akar); ?> </td>
	      <td style=""> <?php echo e($tdk -> dilakukan); ?> </td>
	      <td style=""> <?php echo e($tdk -> pencegahan); ?> </td>
	      <td style="text-align:center; "> <?php echo e($tdk ->title); ?> <br><br>

	      

	      </td>
  		</tr>
  		

	</table><br><br>

	<form class="form-horizontal" action="<?php echo e(route ('updateverifikasi', $tdk->id_tindakan)); ?>" method="post">
		<?php echo e(csrf_field()); ?>


		<div class="form-group row ">
			<div class="col-sm-6">
			<label class="control-label " for="catver"> <h5>  Catatan Verifikasi: </h5></label>
				 
					<textarea cols="50" rows="5" class="form-control" id="catver" placeholder="Masukkan Catatan" name="catver"><?php echo e($tdk->catatan_tindakan); ?> </textarea>
				</div>

				<label class="control-label " for="submit"></label>
				<div class="col-sm-offset-2 col-sm-6">
					<br><br>		
					<button type="submit" class="btn btn-success btn-sm"  ><span class=" fa fa-save " >  Simpan</span></button>
					<input type="hidden" name="_method" value="PUT">					
				</div>
		</div><br><br>

		<!-- <div class="form-group row">  
			<label class="control-label col-sm-2" for="submit"></label>
				<div class="col-sm-offset-2 col-sm-6">
					
					<button type="submit" class="btn btn-success btn-sm"  >Simpan</button>

					<input type="hidden" name="_method" value="PUT">					
				</div>
		</div> --><br><br>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</form>
	</div>

</body><br><br><br><br><br>
</html>
<?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>