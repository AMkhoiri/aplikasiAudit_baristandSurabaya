<!DOCTYPE html>
<html>
<head>

 <?php echo $__env->make('layout.head-css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <?php echo $__env->make('auditor.headerauditor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<title>Edit Pertanyaan</title>
</head>
<body>
	<br><br>
	<div class="container"  style="font-size: 14px; ">
		<h3>Edit Pertanyaan</h3><br>
		<form class="form-horizontal" action="../../../auditor/daftarpertanyaan/<?php echo e($pertanyaan->id); ?>" method="post">
			<?php echo e(csrf_field()); ?>

		   
			<div class="form-group row ">
				<label class="control-label col-sm-2" for="pertanyaan">Pertanyaan : </label>
				<div class="col-sm-6">       
					<textarea cols="50" rows="5" class="form-control" id="pertanyaan" name="pertanyaan"><?php echo e($pertanyaan->pertanyaan); ?></textarea>
				</div>
			</div>

			<div class="form-group row">
			    <label class=" control-label col-sm-2" for="kategori">Kategori : </label>
			    <div class=" col-sm-2 " >
			      <select class="custom-select " id="kategori" name="kategori" value="">
				    <option value="OK">OK</option>
				    <option value="NOK">NOK</option>
			     	</select>
			    </div>
			</div>

			<div class="form-group row">
				<label class="control-label col-sm-2" for="catatan">Catatan : </label>
			    <div class="col-sm-6">
					<textarea cols="50" rows="5" class="form-control" id="catatan" name="catatan"><?php echo e($pertanyaan->catatan); ?></textarea>
			    </div>
			</div>
			   

			<div class="form-group row">  
			    <label class="control-label col-sm-2" for="submit"></label>      
			    <div class="col-sm-offset-2 col-sm-7">
			    	
			        <a  class="btn btn-sm btn-secondary " href="<?php echo e(url ('auditor/daftarpertanyaan')); ?> " style=" width: 65px; " ><span class=" fa fa-arrow-left " >  Batal</span></a>
			        <button type="submit" class="btn btn-primary btn-sm "><span class=" fa fa-save " >  Simpan</span></button>

			        <input type="hidden" name="_method" value="PUT">
			    </div>
			</div>
		</form>
	</div>
	<br><br><br><br><br><br>


</body>
</html>
<?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>