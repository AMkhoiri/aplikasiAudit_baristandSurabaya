<!DOCTYPE html>
<html>
<head>
	<?php echo $__env->make('layout.head-css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<title>Error</title>
	<link href="https://fonts.googleapis.com/css2?family=Roboto+Mono:wght@300&display=swap" rel="stylesheet">
</head>
<body>

<div  class="container"  style=" font-size: 50px; font-family: roboto; opacity: 70%;  text-align: center; margin-top: 180px;  color: #9fa0a1;" > 

	
	<img src="<?php echo e(asset('audit/img/sad.png')); ?>" alt="" style="width: 200px; margin-bottom: 20px; " >
		<h3 style="  text-align: center; color: #9fa0a1;  font-family: 'Roboto Mono', monospace;" >Ooopss...</h3  > 
	<h5 style="  text-align: center; color: #9fa0a1;  font-family: 'Roboto Mono', monospace;" >Anda Tidak Mempunyai Akses Ke Halaman Ini! </h5  > 

	<a  class=" btn btn-sm  " href="<?php echo e(url ('/')); ?>" style=" width: 58px; font-size: 20px;  " > <span class="fa fa-arrow-left" ></span> </a>
</div>

</body>
</html>

