
<!DOCTYPE html>
<html>
<head>
  <title></title>
  <?php echo $__env->make('layout.head-css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</head>
<body>

<table class="table table-bordered "  >

   
     <tr  >
      <th style="text-align:center">NO</th>
      <th style="text-align:center">username</th>
    
      <th style="text-align:center">Lokasi</th>
      <th style="text-align:center">akses</th>
      <th style="text-align:center">Password</th>
      
    </tr>

     <?php $no = 0;?>

  <?php $__currentLoopData = $usrslst; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $no++ ;?>

    <tr> 
      <td style="text-align:center"> <?php echo e($no); ?></td>
      <td style=""> <?php echo e($a->username); ?> </td>
      <td style="">  <?php echo e($a->lokasi); ?></td>
      <td style="text-align:center">  <?php echo e($a->akses); ?></td>
       <td style="text-align:center">  <?php echo e($a->pass); ?></td>
    </tr>
    
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </table>


</body>
</html>


 