<!DOCTYPE html>
<html>
<head>

	<?php echo $__env->make('layout.head-css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->make('admin.headeradmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<title> Data Pegawai </title>
</head>
<body>
		 <br><br><br><br><br>

<div class="container"  style="font-size: 14px; "> 
  

    <h5 style="text-align: center; " >DATA PEGAWAI</h5> 
        
          <a href="<?php echo e(route('tambahpegawai')); ?>"><button class="btn btn-primary btn-sm " style=" width: 125px; "  >  <span class=" fa fa-plus " >  Tambah Pegawai</span> </button></a>
        <br><br>

<div class="table-responsive">
  <table class="table  table-striped table-bordered  "  >
  	
         <tr  >
              <th style="text-align:center">NO</th> 
              <th style="text-align:center">Nama</th>
              <!-- <th style="text-align:center">Jenis Kelamin</th> -->
              <th style="text-align:center">NIP</th>
              <th style="text-align:center">SIE</th>
              <th style="text-align:center">Jabatan</th>
              <!-- <th style="text-align:center">Email</th> -->
              <th style="text-align:center">Aksi</th>   
        </tr>

<?php $no = 0;?>
   <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <?php $no++ ;?>  
    
        <tr>
          
              <td style="text-align:center">  <?php echo e($no); ?> </td>
              <td style=""> <?php echo e($p -> nama); ?> </td>
            <!--   <td style=""> <?php echo e($p -> jenis_kelamin); ?> </td> -->
              <td style="text-align:center"><?php echo e($p -> nip); ?>  </td>
              <td style=""> <?php echo e($p -> sie); ?>  </td>
              <td style=""> <?php echo e($p -> jabatan); ?> </td>
              <!-- <td style=""> <?php echo e($p -> email); ?>  </td> -->
              <td style="text-align:center; width: 165px; " >

                <div class="row" > 
                    <div class=" col-md-6 " > 
                        <a href="<?php echo e(route('editpegawai',$p->id)); ?>"><button class="btn btn-sm btn-primary " style="width: 58px; font-size: 10px;"  ><span class=" fa fa-edit " >  Edit</span></button></a> 
                    </div>

                    <div class=" col-md-6 " > 
                      <form action=" <?php echo e(route('hapuspegawai',$p->id)); ?>"  method="post" >     
                          <input  class="btn btn-danger btn-sm " style="width: 58px; font-size: 10px; "   onclick="return confirm('Anda Yakin Untuk Menghapus <?php echo e($p->nama); ?> ?')" type="submit" name="submit" value="Hapus">
                          <?php echo e(csrf_field()); ?>          
                          <input type="hidden" name="_method" value="DELETE" >
                      </form> 
                    </div>
              </div>
                 
                  
              </td>

        </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
  </div>

  <br><br>
  <br><br>
</div>


<script>
    var msg = '<?php echo e(Session::get('alert')); ?>';
    var exist = '<?php echo e(Session::has('alert')); ?>';
    if(exist){
      alert(msg);
    }
  </script>

</body>
</html>
<?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 