<!DOCTYPE html>
<html>
<head>

 <?php echo $__env->make('layout.head-css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <?php echo $__env->make('auditor.headerauditor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<title>Buat LKS</title>
</head>
<body>
	<?php 

	$id_pertanyaan=$perta->id; 
	$lokasi=$perta->lokasi; 
	
	?>

<br><br>
	<div class="container"  style="font-size: 14px; ">
	  <h5 style="text-align: left; " >Lokasi Audit : <br><?php echo e(Auth::user()->lokasi); ?></h5><br>
	  <h5 style="text-align: center; ">BUAT LAPORAN KETIDAKSESUAIAN</h5><br>
	  <form class="form-horizontal" action="<?php echo e(url ('auditor/daftarlks')); ?>" method="post"> 
	  	<?php echo e(csrf_field()); ?>

		   
		  	<!-- <div class="form-group row ">
		      <label class="control-label col-sm-2" for="nolks" >Nomor LKS  </label>
		      <div class="col-sm-3">          
		        <input type="text" class="form-control" id="nolks" placeholder="Masukkan Nomor" name="nolks" required >
		      </div>
		    </div> -->

		    <div class="form-group row ">
		      <label class="control-label col-sm-2" for="acuan">Dokumen Acuan  </label>
		      <div class="col-sm-7">
		      	<textarea cols="10" rows="4" class="form-control" id="acuan" placeholder="Masukkan Dokumen Acuan" name="acuan" required></textarea>
		      </div>
		    </div>

		    <div class="form-group row">
		      <label class="control-label col-sm-2" for="deksripsi">Deskripsi Ketidaksesuaian </label>
		      <div class="col-sm-7">          
		        <textarea cols="10" rows="6" class="form-control" id="deksripsi" value="" name="deskripsi" required> <?php echo e($perta->catatan); ?> </textarea>
		      </div>
		    </div>

		    <div class="form-group row">
		      <label class="control-label col-sm-2" for="iec_2012"> SNI ISO/IEC 17065:2012 Klausul </label>
		      <div class="col-sm-7">
		      	<select class="custom-select " id="iec_2012" name="iec_2012" >
					        <option value="" >Pilih Klausul (SNI ISO/IEC 17065:2012)</option>
					  	<?php $__currentLoopData = $klausul2012; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					        <option value="<?php echo e($p->klausul); ?>"><?php echo e($p->klausul); ?></option>		       
					    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		     	</select>

		      	<!-- <input type="text" class="form-control" id="iec_2012" placeholder="Masukkan Klausul" name="iec_2012"> -->
		      </div>
		    </div>

		    <div class="form-group row">
		      <label class="control-label col-sm-2" for="iec_2015"> ISO/IEC 17021-1:2015 Klausul </label>
		      <div class="col-sm-7">
		      	<select class="custom-select " id="iec_2015" name="iec_2015" >
					        <option value="" >Pilih Klausul (SNI ISO/IEC 17021-1:2015)</option>
					  	<?php $__currentLoopData = $klausul2015; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					        <option value="<?php echo e($p->klausul); ?>"><?php echo e($p->klausul); ?></option>		       
					    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		     	</select>
		      </div>
		    </div>

		    <div class="form-group row">
		      <label class="control-label col-sm-2" for="iec_2017"> ISO/IEC 17021-3:2017 Klausul </label>
		      <div class="col-sm-7">
		      	<select class="custom-select " id="iec_2017" name="iec_2017" >
					        <option value="" >Pilih Klausul (SNI ISO/IEC 17021-3:2017)</option>
					  	<?php $__currentLoopData = $klausul2017; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					        <option value="<?php echo e($p->klausul); ?>"><?php echo e($p->klausul); ?></option>		       
					    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		     	</select>
		      </div>
		    </div>

		    <div class="form-group row">
		      <label class="control-label col-sm-2" for="smm">Tidak Sesuai Dengan (Dokumen SMM) </label>
		      <div class="col-sm-7">
		      	<input type="text" class="form-control" id="smm" placeholder="Masukkan Dokumen SMM" name="smm">
		      </div>
		    </div>
		    <input type="hidden" class="form-control" id="id_pertanyaan" value="<?php echo e($id_pertanyaan); ?>" name="id_pertanyaan">

		    <input type="hidden" class="form-control" id="lokasi" value="<?php echo e($lokasi); ?>" name="lokasi">

		    <input type="hidden" class="form-control" id="Status" value="LKS Telah Dibuat" name="status">

		    <div class="form-group row">  
		    	<label class="control-label col-sm-2" for="submit"></label>      
		      <div class="col-sm-offset-2 col-sm-8">
		      	 <a  class="btn btn-sm btn-secondary " href="<?php echo e(url ('auditor/daftarpertanyaan')); ?> " style=" width: 65px; " ><span class=" fa fa-arrow-left " >  Batal</span></a>
		        <button type="submit" class="btn btn-primary btn-sm "><span class=" fa fa-save " >  Simpan</span></button>
		      </div>
		      <br><br><br>
		    </div> 
		</form>
	</div>

</body>
 <?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</html>