<!DOCTYPE html>
<html>
<head>

 <?php echo $__env->make('layout.head-css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <?php echo $__env->make('auditor.headerauditor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<title>Form Tambah Pertanyaan</title>
</head>
<body>
	<br><br>
	<div class="container"  style="font-size: 14px; ">
	  
	  <h3 style="">Tambah Pertanyaan</h3><br>
		<form class="form-horizontal" action="<?php echo e(url ('auditor/daftarpertanyaan')); ?>" method="post">
			<?php echo e(csrf_field()); ?>

		   
			<div class="form-group row ">
				<label class="control-label col-sm-2" for="pertanyaan">Pertanyaan : </label>
				<div class="col-sm-6"> 
					<textarea cols="50" rows="5" class="form-control" id="pertanyaan" placeholder="Masukkan Pertanyaan" name="pertanyaan" required></textarea>
				</div>
			</div>

			<div class="form-group row">
			    <label class=" control-label col-sm-2" for="kategori">Kategori : </label>
			    <div class=" col-sm-2 " >
			      <select class="custom-select " id="kategori" name="kategori">
				    <option value="OK">OK</option>
				    <option value="NOK">NOK</option>
			     	</select>
			    </div>
			</div>

			<div class="form-group row">
				<label class="control-label col-sm-2" for="catatan">Catatan : </label>
			    <div class="col-sm-6">
			    	<textarea cols="50" rows="5" class="form-control" id="catatan" placeholder="Masukkan Catatan" name="catatan"></textarea>
			    </div>
			</div>

			<div class="form-group row">
				
			   <input type="hidden" name="lokasi" value=" <?php echo e($auditor->lokasi_audit); ?> " >
			    <input type="hidden" name="penulis" value=" <?php echo e(Auth::user()->username); ?> " >
			</div>
			   

			<div class="form-group row">  

			    <label class="control-label col-sm-2" for="submit"></label>      
			    <div class="col-sm-offset-2 col-sm-6">
			    	<!-- <a href="<?php echo e(url ('daftarpertanyaan')); ?>"> <button class=" btn " >Kembali</button> </a> -->

			        <a  class="btn btn-sm btn-secondary " href="<?php echo e(url ('auditor/daftarpertanyaan')); ?> " style=" width: 65px; " > <span class=" fa fa-arrow-left " >  Batal</span></a>

			        <button type="submit" class="btn btn-primary btn-sm "> <span class=" fa fa-save " > Simpan</span></button>

			    </div><br><br><br><br><br>

			</div>
		</form>

	</div>


</body>
</html>
<?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>