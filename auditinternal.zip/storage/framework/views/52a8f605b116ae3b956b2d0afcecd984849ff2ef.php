<!DOCTYPE html>
<html>
<head>

 <?php echo $__env->make('layout.head-css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <?php echo $__env->make('auditor.headerauditor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

 <style>
 
  </style>

	<title>Daftar Laporan Ketidakseuaian</title>
</head>
<body>


	<br><br>
	<div class="container" style=" font-size: 12px "  > 

		<h5 class=" " >Area Audit : <br>

       <?php if(Auth::user()->lokasi==NULL): ?>
    <i style=" color: red; " > Akun Anda Tidak Aktif, Silahkan Hubungi Admin !</i>
    <?php else: ?>
    <?php echo e(Auth::user()->lokasi); ?>

    <?php endif; ?>

    </h5><br>
    <h5   class="  text-center ">DAFTAR LAPORAN KETIDAKSESUAIAN</h5><br>


    <div class="table-responsive">
		<table class="table table-striped table-bordered"  >

    	<tr>

      	<th class="  text-center ">No LKS</th>
        <th class="  text-center ">Dokumen Acuan</th>
      	<th class="  text-center ">Deskripsi Ketidaksesuaian</th>
      
        <th class="  text-center ">Tidak Sesuai Dengan</th>
        <th class="  text-center ">Aksi</th>
         <th class="  text-center ">Status</th>
    
    	</tr>


      <?php $no = 0;?>

    <?php $__currentLoopData = $lks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php $no++ ;?> 

    <tr>  
      <td class="  text-center "><b><?php echo e($lk -> nolks); ?></b> </td>
      <td style=" width: 220px"> <?php echo e($lk -> acuan); ?> </td>
      <td style=" width: 380px" > <?php echo e($lk -> deskripsi); ?> </td>
    
      <td style=" width: 250px " > <b>SNI ISO/IEC 17065:2012 Klausul: </b><br><?php echo e($lk -> iec_2012); ?> <br><b>ISO/IEC 17021-1:2015 Klausul:<br> </b> <?php echo e($lk -> iec_2015); ?> <br><b> ISO/IEC 17021-3:2017 Klausul: </b><br>  <?php echo e($lk -> iec_2017); ?> <br><b>(Dokumen SMM): </b><br><?php echo e($lk -> smm); ?></td>

      <td style="text-align:center;" >
         <?php if( $lk->status==NULL): ?>
          <a href="<?php echo e(route('editlks',$lk->id)); ?>"><button class="btn btn-primary btn-sm" style=" width: 58px; "> <span  style="font-size: 11px " class=" fa fa-edit " > Edit</span></button></a>
       
<?php    $nama= $auditor->nama; ?>
     <br><br>
        <form class="form-horizontal" action="<?php echo e(route('kirimlks',$lk->id)); ?>" method="post">
          <?php echo e(csrf_field()); ?>      
              <input type="hidden" class="form-control" id="status" name="status" value="Terkirim">
              <input type="hidden" class="form-control" id="nama" name="nama" value="<?php echo e($nama); ?>"> 
               <input type="hidden" class="form-control" id="nlks" name="nolks" value="<?php echo e($no); ?>">          
              <button type="submit" style="width: 58px;  "  class="btn btn-sm btn-success" onclick="return confirm('Setelah Terkirim, Anda tidak akan bisa mengubahnya lagi. yakin untuk mengirim LKS ini Ke Auditee ? ')" ><span  style="font-size: 11px " class=" fa fa-send " > Kirim</button>

              <input type="hidden" name="_method" value="PUT">
          </form>
 
           <?php else: ?>
          
          <?php endif; ?>
      </td>

      <td style=" text-align: center; " >
          <?php if( $lk->status==NULL): ?>
  
          <?php else: ?>
          <i class="fa fa-check"  style=" font-size: 1.2em;width: 1.6em;text-align: center;line-height: 0.8em;background: green;color: #fff;border-radius: 0.8em; " >  </i><br>
          <?php echo e($lk->status); ?>

         
          
          <?php endif; ?>
      </td>
    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
  </table>
  </div>
</div>

</body><br><br><br><br><br>


<script>
    var msg = '<?php echo e(Session::get('alert')); ?>';
    var exist = '<?php echo e(Session::has('alert')); ?>';
    if(exist){
      alert(msg);
    }
  </script>
  
</html>
 <?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>