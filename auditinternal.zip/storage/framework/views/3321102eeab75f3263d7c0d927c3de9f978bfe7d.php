<!DOCTYPE html>
<html>
<head>
	<?php echo $__env->make('layout.head-css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->make('kepala.headerkepalabalai', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<title> Kepala Balai - Pilih Auditor</title>
</head>
<body>


	<div class="container"   style="font-size: 14px;"> 

			<div  class="form-group row "  >
				  
                            <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger col-sm-9 " style=" align-content: center; " >
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
			</div>

		<h5>PILIH AUDITOR</h5><br>
		<div class="form-group row "> 
		<h6 class="col-sm-3" ><b> Lokasi Audit </b></h6>
		<h6 class="col-sm-6" ><b> Nama Auditor </b></h6>
		</div>

		 <div class="form-group row ">
		      <label class="control-label col-sm-3" for="nama">Top Manajemen</label>
		      <div class="col-sm-6"> 

		      <table class="table " > 		      
		      <?php $no = 0;?> 
		<?php $__currentLoopData = $auditor1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
		      <?php $no++ ;?>  

		      	<tr>
		      		<td><?php echo e($no); ?></td>
		      		<td><?php echo e($a->nama); ?></td>
		      		<td align="right" >	
					  <form action=" ../kepala/auditor/<?php echo e($a->id); ?>"  method="post" >     
				          <input  class="btn btn-danger btn-sm " style=""  onclick="return confirm('Anda Yakin menghapus <?php echo e($a->nama); ?> dari Auditor ?')" type="submit" name="submit" value="Hapus">
				          <?php echo e(csrf_field()); ?>

				           
				          <input type="hidden" name="_method" value="DELETE" >
			      	</form>
		      		</td>
		      	</tr>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		      </table>

		             
		        <form action="<?php echo e(url('kepala/auditor/create')); ?>" method="post"> 
			        	 <?php echo e(csrf_field()); ?>

			 				
			 			<select class="custom-select " id="Sie" name="nama" required>
					        <option value="" >Pilih Auditor</option>
					  	<?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					        <option value="<?php echo e($p->nama); ?>"><?php echo e($p->nama); ?></option>
					         <?php $id= $p->id; ?>
					    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		     			</select>

		     			 	<input type="hidden" name="lokasi_audit" class="form-control" value="Top Manajemen"  required/><br>
		     			  <br>
			 				<button  type="submit" class="btn btn-sm btn-primary " >Simpan</button>
			             
			 	</form>
			 </div> <hr>
		</div>

		<br><br><br>


		 	 <div class="form-group row ">
		      <label class="control-label col-sm-3" for="nama">Sub Bag Tata Usaha</label>
		      <div class="col-sm-6"> 

		      <table class="table " > 		      
		      <?php $no = 0;?> 
		<?php $__currentLoopData = $auditor2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
		      <?php $no++ ;?>  

		      	<tr>
		      		<td><?php echo e($no); ?></td>
		      		<td><?php echo e($a->nama); ?></td>
		      		<td align="right">	
					  <form action=" ../kepala/auditor/<?php echo e($a->id); ?>"  method="post" >     
				          <input  class="btn btn-danger btn-sm " style=""  onclick="return confirm('Anda Yakin menghapus <?php echo e($a->nama); ?> dari Auditor ?')" type="submit" name="submit" value="Hapus">
				          <?php echo e(csrf_field()); ?>

				           
				          <input type="hidden" name="_method" value="DELETE" >
			      	</form>
		      		</td>
		      	</tr>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		      </table>

		             
		        <form action="<?php echo e(url('kepala/auditor/create')); ?>" method="post"> 
			        	 <?php echo e(csrf_field()); ?>

			 				
			 			<select class="custom-select " id="Sie" name="nama" required>
					        <option value="" >Pilih Auditor</option>
					  	<?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					        <option value="<?php echo e($p->nama); ?>"><?php echo e($p->nama); ?></option>
					         <?php $id= $p->id; ?>
					    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		     			</select>

		     			 	<input type="hidden" name="lokasi_audit" class="form-control" value="Sub Bag Tata Usaha"  required/><br>
		     			  <br>
			 				<button  type="submit" class="btn btn-sm btn-primary " >Simpan</button>
			             
			 	</form>
			 </div><hr>
		</div>

		 <br><br><br>



		 	 <div class="form-group row ">
		      <label class="control-label col-sm-3" for="nama">Seksi Pengembangan jasa Teknis</label>
		      <div class="col-sm-6"> 

		      <table class="table " > 		      
		      <?php $no = 0;?> 
		<?php $__currentLoopData = $auditor3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
		      <?php $no++ ;?>  

		      	<tr>
		      		<td><?php echo e($no); ?></td>
		      		<td><?php echo e($a->nama); ?></td>
		      		<td align="right">	
					  <form action=" ../kepala/auditor/<?php echo e($a->id); ?>"  method="post" >     
				          <input  class="btn btn-danger btn-sm " style=""  onclick="return confirm('Anda Yakin menghapus <?php echo e($a->nama); ?> dari Auditor ?')" type="submit" name="submit" value="Hapus">
				          <?php echo e(csrf_field()); ?>

				           
				          <input type="hidden" name="_method" value="DELETE" >
			      	</form>
		      		</td>
		      	</tr>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		      </table>
        
		        <form action="<?php echo e(url('kepala/auditor/create')); ?>" method="post"> 
			        	 <?php echo e(csrf_field()); ?>

			 				
			 			<select class="custom-select " id="Sie" name="nama" required>
					        <option value="" >Pilih Auditor</option>
					  	<?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					        <option value="<?php echo e($p->nama); ?>"><?php echo e($p->nama); ?></option>
					         <?php $id= $p->id; ?>
					    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		     			</select>

		     			 	<input type="hidden" name="lokasi_audit" class="form-control" value="Seksi Pengembangan jasa Teknis"  required/><br>
		     			  <br>
			 				<button  type="submit" class="btn btn-sm btn-primary " >Simpan</button>
			             
			 	</form>
			 </div><hr>
		</div>

		 <br> <br><br>



		 	 <div class="form-group row ">
		      <label class="control-label col-sm-3" for="nama">Seksi Standarisasi Dan Sertifikasi / Operasional</label>
		      <div class="col-sm-6"> 

		      <table class="table " > 		      
		      <?php $no = 0;?> 
		<?php $__currentLoopData = $auditor4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
		      <?php $no++ ;?>  

		      	<tr>
		      		<td><?php echo e($no); ?></td>
		      		<td><?php echo e($a->nama); ?></td>
		      		<td align="right">	
					  <form action=" ../kepala/auditor/<?php echo e($a->id); ?>"  method="post" >     
				          <input  class="btn btn-danger btn-sm " style=""  onclick="return confirm('Anda Yakin menghapus <?php echo e($a->nama); ?> dari Auditor ?')" type="submit" name="submit" value="Hapus">
				          <?php echo e(csrf_field()); ?>

				           
				          <input type="hidden" name="_method" value="DELETE" >
			      	</form>
		      		</td>
		      	</tr>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		      </table>

		             
		        <form action="<?php echo e(url('kepala/auditor/create')); ?>" method="post"> 
			        	 <?php echo e(csrf_field()); ?>

			 				
			 			<select class="custom-select " id="Sie" name="nama" required>
					        <option value="" >Pilih Auditor</option>
					  	<?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					        <option value="<?php echo e($p->nama); ?>"><?php echo e($p->nama); ?></option>
					         <?php $id= $p->id; ?>
					    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		     			</select>

		     			 	<input type="hidden" name="lokasi_audit" class="form-control" value="Seksi Standarisasi Dan Sertifikasi / Operasional"  required/><br>
		     			  <br>
			 				<button  type="submit" class="btn btn-sm btn-primary " >Simpan</button>
			             
			 	</form>
			 </div><hr>
		</div>

		 <br><br><br>



		 	 <div class="form-group row ">
		      <label class="control-label col-sm-3" for="nama">Seksi Standarisasi Dan Sertifikasi / Mutu</label>
		      <div class="col-sm-6"> 

		      <table class="table " > 		      
		      <?php $no = 0;?> 
		<?php $__currentLoopData = $auditor5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
		      <?php $no++ ;?>  

		      	<tr>
		      		<td><?php echo e($no); ?></td>
		      		<td><?php echo e($a->nama); ?></td>
		      		<td align="right">	
					  <form action=" ../kepala/auditor/<?php echo e($a->id); ?>"  method="post" >     
				          <input  class="btn btn-danger btn-sm " style=""  onclick="return confirm('Anda Yakin menghapus <?php echo e($a->nama); ?> dari Auditor ?')" type="submit" name="submit" value="Hapus">
				          <?php echo e(csrf_field()); ?>

				           
				          <input type="hidden" name="_method" value="DELETE" >
			      	</form>
		      		</td>
		      	</tr>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		      </table>

		           
		        <form action="<?php echo e(url('kepala/auditor/create')); ?>" method="post"> 
			        	 <?php echo e(csrf_field()); ?>

			 				
			 			<select class="custom-select " id="Sie" name="nama" required>
					        <option value="" >Pilih Auditor</option>
					  	<?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					        <option value="<?php echo e($p->nama); ?>"><?php echo e($p->nama); ?></option>
					         <?php $id= $p->id; ?>
					    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		     			</select>

		     			 	<input type="hidden" name="lokasi_audit" class="form-control" value="Seksi Standarisasi Dan Sertifikasi / Mutu"  required/><br>
		     			  <br>
			 				<button  type="submit" class="btn btn-sm btn-primary " >Simpan</button>
			             
			 	</form>
			 </div><hr>
		</div>

		 <br>




	 </div>


</body>
</html>
<?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>