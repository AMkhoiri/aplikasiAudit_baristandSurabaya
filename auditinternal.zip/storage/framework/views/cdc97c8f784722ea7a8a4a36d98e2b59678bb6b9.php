 <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1,shrink-to-fit=no">
    <!-- <link rel="icon" href="../public/enjoybali/img/favicon.png" type="image/png"> -->

    <!--  <link rel="icon" href="../public/audit/img/favicon.png" type="image/png"> -->

      <link rel="icon"  href="<?php echo e(asset('audit/img/favicon.png')); ?>" type="image/png">


    <link rel="stylesheet" href="<?php echo e(asset('audit/css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('audit/vendors/linericon/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('audit/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('audit/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('audit/css/magnific-popup.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('audit/vendors/owl-carousel/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('audit/vendors/nice-select/css/nice-select.css')); ?>">

     <link rel="stylesheet" href="<?php echo e(asset('audit/css/style.css')); ?>">
     
<link href="https://fonts.googleapis.com/css2?family=Kumbh+Sans:wght@300;400&display=swap" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">
  
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
 <script src="<?php echo e(asset('audit/admin/assets/js/vendor/jquery-2.2.4.min.js')); ?>"></script>